<?php
// AJAX TOKEN
$token = wp_create_nonce("wp_token");
$theblogtitle = of_get_option('md_theblog_title');	
$categoriestitle = of_get_option('md_theblog_categories_title');
$dropdowncategories = of_get_option('md_theblog_categories_dropdown');

if(!of_get_option('md_theblog_limit')) {
	$bloglimit = 10;
}else{
	$bloglimit = of_get_option('md_theblog_limit');
}

if($bloglimit == 0) {
	$bloglimit = -1;
}

// SHOW SIDEBAR WHETHER OR NOT
$dontshow_sidebar = of_get_option('md_posts_sidebar');

// GET POSTS
if(!is_archive()) {
	global $more; $more = 0; 
	
	
	$page = md_get_page_number();
	
	
	$args = array(
		'more'=>1,
		'post_type' => 'post',
		'orderby' => 'post_date',
		'order'=>'desc',
		'posts_per_page' => $bloglimit,
		'paged'=>$page,
		'cat'=>$cat,
		'post_status' => array('publish')
	);
	query_posts( $args );
}

$bloglink = of_get_option('md_theblog_homelink');
?>
     
	<?php if(!of_get_option('md_all_titles_disable')==1) {?> 
         <div class="columns navibg withall border-color">
            <div class="four columns alpha">
            	<h3>
					<?php if(is_archive()) { ?>
					<?php if ( is_day() ) : ?>
                                    <?php printf( __( 'Daily Archives: <span>%s</span>', 'dronetv' ), get_the_date() ); ?>
                    <?php elseif ( is_month() ) : ?>
                                    <?php printf( __( 'Monthly Archives: <span>%s</span>', 'dronetv' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'dronetv' ) ) ); 			?>
                    <?php elseif ( is_year() ) : ?>
                                    <?php printf( __( 'Yearly Archives: <span>%s</span>', 'dronetv' ), get_the_date( _x( 'Y', 'yearly archives date format', 'dronetv' ) ) ); ?>
                    <?php else : ?>
                    	
                        <a href="<?php if($bloglink) { echo get_permalink($bloglink); }?>">
                             <?php if($theblogtitle=="") { echo _e('Blog','dronetv'); }else{ echo $theblogtitle; }  ?>
                        </a> 
                                       
                    <?php endif; ?>
                    
                    <?php }else{ ?>
                    
                        <a href="<?php if($bloglink) { echo get_permalink($bloglink); }?>">
                            <?php if($theblogtitle=="") { echo _e('Blog','dronetv'); }else{ echo $theblogtitle; }  ?>
                        </a>
					
					<?php } ?>
                </h3>
            </div>
            
            <div class="twelve columns omega">
            	<div class="navigate">
                	<hr class="resshow border-color" />
                    <div class="fullnav <?php if($dropdowncategories==1) echo 'dropdown';?>">
					 <div class="menuwrapper">
                     <?php if($dropdowncategories==1) { ?>
                    	<a href="#" class="categoriesdd">
							<?php if($categoriestitle=="") { echo _e('CATEGORIES','dronetv'); }else{ echo $categoriestitle; }  ?> 
                            <strong><?php if(single_cat_title()) echo single_cat_title()?></strong>
                            <span class="arrow-down"></span>
                        </a>
                     <?php } ?>   
                        <ul>
						<?php 
                        // GET CATEGORIES
							
						$cats = $wpdb->get_results("SELECT w.term_id, wp.term_taxonomy_id, w.name, w.slug FROM ".$wpdb->terms." w, ".$wpdb->term_taxonomy." wp 
						WHERE wp.term_id=w.term_id AND wp.taxonomy='category' order by w.term_ordering asc, w.name asc", OBJECT);
								
                        $count_cats = count( $cats ); 
                        if ( $count_cats > 0 ) {
						   foreach ($cats as $catd) { 
						?>
							<li>
							<a href="<?php echo get_category_link( $catd->term_id ); ?>" class="activemenu-bg <?php if($catd->term_id==$cat) { echo 'selected'; } ?>" data-rel="<?php echo $catd->slug; ?>" title="<?php echo $catd->name; ?>"><?php if(function_exists('mb_strtoupper')) { echo mb_strtoupper($catd->name); }else{ echo strtoupper($catd->name); } ?></a>
							</li>
						<?php } ?>
                    <?php } ?>
                    
                        </ul>
                      </div>
                    </div>
                <select class="responsiveselect reschangeblog border-color">
                    <option value="<?php if($bloglink) { echo get_permalink($bloglink); }?>" selected=""><?php _e('Categories...','dronetv')?></option>
                    <?php		
                   foreach ($cats as $catd) { 
                    ?>
                    <option value="<?php echo get_category_link( $catd->term_id ); ?>" <?php if($catd->term_id==$cat) { echo 'selected'; } ?>><?php echo ($catd->name); ?></option>
                    <?php } ?>
                </select>
                </div>	
              </div>
       </div>
       <?php } ?> 

         	<div class="works-single hidden"></div>
            
			<br class="clear">
            
<div id="post-list" class="row blogpage fitvids">
	<div class="<?php if(!$dontshow_sidebar) { echo 'two-thirds column'; }else{ echo 'sixteen columns'; } ?>">
            <?php  while ( have_posts() ) : the_post(); ?>    
	
    <div <?php post_class('blogpost border-color'); ?>>
                   
                    <h3><a href="<?php the_permalink() ?>" data-type="blog" data-id="<?php echo $post->ID?>" data-token="<?php echo $token?>"><?php the_title(); ?></a></h3>
                    <div class="title border-color">
                        <?php 
					   	if(of_get_option('md_post_show_category')) { 
					     $sep=1;
					    ?>
					    <strong><?php _e('Category','dronetv'); ?> :</strong> <?php the_category(', '); ?> 
                        <?php } ?>
						<?php 
						if(of_get_option('md_post_show_comments')) { 
							if(isset($sep)) echo ' · ';
								$sep=1;
						?>
			 <a href="<?php comments_link(); ?>"><?php comments_number(__('No Comments', 'dronetv'), __('<strong>(1)</strong> Comment', 'dronetv'), __('<strong>(%)</strong> Comments', 'dronetv')); ?></a>
					    <?php } ?> 
                        <?php 
						if(of_get_option('md_post_show_author')) { 
								if(isset($sep)) echo ' · ';
								$sep=1;
								echo  _e('by ', 'dronetv'); the_author_posts_link(); 
						}
						?>
                        <?php 
						if(of_get_option('md_post_show_date')) {
						$sep=1; 
						?>
                        <span class="datetime">
							<?php echo date_i18n(get_option('date_format'),strtotime(get_the_time( get_option('date_format'), $post->ID ))); ?> 
                        </span>
                        <?php } ?>
                    </div>
                    <?php 
					
						if ( post_password_required() ) {
							
							the_excerpt(); 
							echo '<br class="clear">';
						
						}else{
							
						if(has_post_thumbnail()) { ?>										
		    			<a href="<?php the_permalink() ?>" data-type="blog" data-id="<?php echo $post->ID?>" data-token="<?php echo $token?>"><?php the_post_thumbnail('large', array('class' => 'postThumb', 'alt' => ''.get_the_title().'', 'title' => ''.get_the_title().'')); ?></a>		
				   
					  <?php the_excerpt(); ?>
                      
                       <?php }else{ ?>
                       
                         <?php the_content(''); ?>
                       
					   <?php } 
					   
						}
						?>	
                   	  <div class="bottom">
                      
                     	<a href="<?php the_permalink() ?>" class="activemenu-bg readmore" data-type="blog" data-id="<?php echo $post->ID?>" data-token="<?php echo $token?>"><?php _e('Read More...','dronetv'); ?></a>
                      	
                        <span class="loop-tags">
                        <?php 
							$posttags = get_the_tags();
								if ($posttags) {
								  foreach($posttags as $tag) {
									echo '<a href="'.get_tag_link($tag->term_id).'" class="tags border-color">'.$tag->name . '</a>';
								  }
								}
						?>
                        </span>
					  </div>
                       
                   </div>
					
			<?php $p++; endwhile; ?>
		
            <?php 
				$pglink = get_paginate_page_links();
			?>
                        
            <?php if($pglink) { ?>     
               <div class="navigation-bottom-works navigation-bottom-blog border-color">         
               	<?php echo $pglink;?>
               </div>
            <?php } ?>

    </div>


      <?php if(!$dontshow_sidebar) { ?>
        <div class="one-third column">
                    <?php get_template_part( 'sidebar', 'blog' ); ?>
        </div>
   	  <?php } ?>
</div>   
    