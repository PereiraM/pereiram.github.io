<?php get_header(); ?>

        <?php if(!of_get_option('md_page_disable_titles')) { ?>
		<div class="sixteen columns navibg withall border-color">
            	<h3 style="margin-left:0;"><?php the_title(); ?></h3>
        </div>
        <?php } ?>
        
	<br class="clear" />
    
	<div class="defaultpage">
  
		<?php 
            if ( post_password_required() ) {
                                
                echo '<div class="two-thirds column passprotectpage">';
                $excerpt = get_the_password_form();
                echo $excerpt;
                echo '</div>';
                
            }else{				
        ?>
  	
		<?php if ( have_posts() ) { the_post(); ?>
            <div class="two-thirds column">
                <?php the_content(); ?>
            </div>
        <?php } ?>
        
	<?php } ?>
    
    
        <div class="one-third column">
             <?php get_template_part( 'sidebar', 'page' ); ?>
        </div>
	</div>	
<?php get_footer(); ?>
	