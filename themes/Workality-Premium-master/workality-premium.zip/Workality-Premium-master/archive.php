<?php
global $wp_query;
$post_obj = $wp_query->get_queried_object();
?>
<?php get_header(); ?>

<div id="loadintothis">
	<?php 
		if(isset($post_obj->taxonomy)) {
			get_template_part( 'works', 'index' );
		}else{
			get_template_part( 'loop', 'index' );	
		}
	?>
</div>
<?php get_footer(); ?>
