<?php 

/// POST TYPE SELECTION

if(have_posts()) { 
	the_post(); 
}elseif(wp_verify_nonce( $_REQUEST['token'], "wp_token" )) { 
	$post = get_post( $_REQUEST['id'] );
	setup_postdata($post);
}	

global $page_type;
if(!isset($page_type)) {
	$page_type = getCustomPage();
}
global $customtypes;
if(!isset($customtypes)) {
	$customtypes = of_get_option('md_custom_posts');
}

$vartype = $customtypes[$page_type];
	
	
$postname = $vartype['title'];
$thumb = $vartype['thumbnail'];
$workstitle = $vartype['plural'];
$categoriestitle = $vartype['categoryname'];
$categoryname = $vartype['title'].'-categories';
$dropdowncategories = $vartype['dropdown'];
$portfoliolink = @$vartype['home_url'];
$works_pagination = intval($vartype['pagination']);
$hideheader = intval($vartype['hideheader']);
$hideprojectinfo = intval($vartype['projectinfo']);
$orderby = intval($vartype['orderby']);

	// REMOVE MARGINS
	$remove_margins = $vartype['removesidemargin'];
	if($remove_margins) { $marginclass= 'sixteen'; $portraitclass= 'eight'; }else{  $marginclass= 'fifteensp offset-by-half'; $portraitclass= 'eightsp'; }
	
	
	// AJAX TOKEN
	$token = wp_create_nonce("wp_token");
	
	global $post;
	$prev_post = getNextBack('prev',$postname,$post->menu_order,$post->post_date,$orderby);
	$next_post = getNextBack('next',$postname,$post->menu_order,$post->post_date,$orderby);



	/// GET DIRECT LINK OR DEFAULT
	$work_direct_link_active = get_post_meta( $post->ID , 'work-direct-link-activate', true );
	
	if($work_direct_link_active==1) {
		$work_direct_link = get_post_meta( $post->ID , 'work-direct-link', true );
	}
	
	/// PUT STYLES
	//if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
		workStyles();	
	//}
	?>	
		
<div id="singlecontent">

		<?php if($hideheader!=1) {?>
		<div class="columns navibg border-color" <?php if($remove_margins) { echo 'style="background:none"'; } ?>>
            <div class="four columns alpha">
            	<h3 <?php if($remove_margins) { echo 'style="margin-left:0"'; } ?>>
					<a href="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>"><?php echo $workstitle; ?></a>
                </h3>
            </div>
            
            <div class="twelve columns omega">
            	<div class="navigate" <?php if($remove_margins) { echo 'style="margin-right:0"'; } ?>>
                	<hr class="resshow border-color" /> 
                    <span class="pname"></span>
                    <a href="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>" data-title="All" title="<?php echo $workstitle;?>" data-type="<?php echo $page_type?>" data-token="<?php echo $token?>" class="navigate parent getworks-showmsg getworks">&nbsp;</a>
                    <?php if(!empty( $prev_post['ID'] )) { ?>
                    <a href="<?php echo get_permalink($prev_post['ID']); ?>" data-type="<?php echo $postname?>" data-token="<?php echo $token?>" data-id="<?php echo $prev_post['ID']?>" title="<?php echo htmlspecialchars($prev_post['post_title'])?>" class="navigate back getworks getworks-showmsg">&nbsp;</a>
                    <?php } ?>
                    <?php if(!empty( $next_post['ID'] )) { ?>
                    <a href="<?php echo get_permalink($next_post['ID']); ?>" data-type="<?php echo $postname?>" data-token="<?php echo $token?>" data-id="<?php echo $next_post['ID']?>" title="<?php echo htmlspecialchars($next_post['post_title'])?>" class="navigate next getworks getworks-showmsg">&nbsp;</a>
					<?php } ?>
            	</div>
            </div>	
        </div>
  	<?php } ?>
  
	<?php
    
        $permalink = get_permalink( $post->ID );
        $work_media = unserialize(get_post_meta( $post->ID, 'work-media', true ));
        $work_client = get_post_meta( $post->ID, 'work-client', true );
        $work_url = get_post_meta( $post->ID, 'work-url', true );
		//$work_date = date_i18n(get_option('date_format') ,strtotime(get_post_meta( $post->ID, 'work-date', true )));
		$work_date = get_post_meta( $post->ID, 'work-date', true );
        $terms = get_the_terms( $post->ID , $categoryname, 'string' );
		$descpos = get_post_meta( $post->ID , 'work-desc-position', true );
		
		$wgallery = get_post_meta( $post->ID , 'work-comp-type', true );
		
		$work_client_title = get_post_meta( $post->ID , 'work-client-title', true );
		$work_date_title = get_post_meta( $post->ID , 'work-date-title', true );
		$work_url_title = get_post_meta( $post->ID , 'work-url-title', true );
		 
        
        if ( $terms && ! is_wp_error( $terms ) ) {
        	$draught_links = array();
        
			foreach ( $terms as $term ) {
				$draught_links[] = '<a href="'.esc_attr(get_term_link( $term, $categoryname )).'">'.$term->name.'</a>';
			}
       		$categories = join( ", ", $draught_links );
        }
        

    ?>      
         <div class="postwraps sixteen columns showajaxcontent border-color">
         
         		<?php 
					//// IF EXTERNAL URL IS DEFINED, DISPLAY THUMBNAIL ONLY
					if($work_direct_link_active==1) {
				?>
                <div class="sixteen columns alpha" style="text-align:center; padding:80px 0 80px 0">
                	<?php 
						$getfull = getThumb('large');
						
					?>
                    <a href="<?php echo $work_direct_link?>" target="_blank">
                    <img src="<?php echo $getfull[0];?>" data-small="<?php echo $getfull[0]?>" data-large="<?php echo $getfull[0]?>" title="<?php echo get_the_title()?>" alt="<?php echo get_the_title()?>" />	
                    </a>
                    <br /><br />
                    <h3 class="titles" style="text-shadow:none!important;"><i class="icon-share" style="position:relative;top:10px"></i> <a href="<?php echo $work_direct_link?>" target="_blank" style="text-shadow:none!important;"><?php the_title(); ?></a></h3>
                </div>
                
                <?php 
					////DISPLAY PROJECT
					}else{ 
				?>
                
                      <div class="<?php echo $marginclass?> columns alpha">
                           <h2 class="titles" style="text-shadow:none!important;"><a href="<?php echo $permalink ?>" style="text-shadow:none!important;"><?php the_title(); ?></a></h2>
                           <hr class="border-color-works" />
                      </div>  
                      <?php 
					  
						if ( post_password_required() ) {
							
							echo '<div class="'.$marginclass.' columns alpha">';
							$excerpt = get_the_password_form();
							echo $excerpt;
							echo '</div>';
							
						}else{


					  	if(!$hideprojectinfo) { 
					  ?>
                      <div class="<?php echo $marginclass?> columns alpha pinfo">
                           <div class="four columns alpha">
                           		<?php if(isset($categories) && $categories!="") {?>
                                <strong><?php echo $categoriestitle?></strong> <br />
                                <?php echo $categories; ?>  
                                <?php } ?>
                          </div> 
                          <div class="four columns">
                           		<?php if($work_client!="") {?>
                                <strong><?php if($work_client_title!="") { echo $work_client_title; }else{ _e('Client','dronetv'); }?></strong> <br />
                                <?php echo makeClickableLinks($work_client); ?>
                                <?php } ?>
                          </div> 
                           <div class="four columns">
                           		<?php if($work_url!="") {?>
                                <strong><?php if($work_url_title!="") { echo $work_url_title; }else{ _e('Project URL','dronetv'); }?></strong> <br />
                                <?php echo makeClickableLinks($work_url); ?>
                                <?php } ?>
                          </div>
                           <div class="three columns omega">
                           		<?php if(get_post_meta( $post->ID, 'work-date', true )) {?>
                                <strong><?php if($work_date_title!="") { echo $work_date_title; }else{ _e('Completion Date','dronetv'); }?></strong><br />
                                <?php echo makeClickableLinks($work_date); ?> 
                                <?php } ?>  
                          </div>
            			  <br class="clear" />
                          <hr class="border-color-works" />
                      </div>
                      <?php } ?>
                      
                      <?php 
					  	  $sharittop = of_get_option('md_social_post_disable_top');
						 if(!$sharittop) {
							  if($remove_margins) { $coln = 'thirteen'; }else{ $coln = 'twelve'; } 
						 }
						  
						  $workdesc = '<br class="clear" /><div class="'.$marginclass.' columns worksrichcontent alpha fitvids">';
						  
						  if(!$sharittop) {
						  	$workdesc .=  '<div class="'.$coln.' columns alpha">';
						  }
						  $workdesc .= apply_filters('the_content', $post->post_content);
						  
						  if(!$sharittop) {
						  	$workdesc .= '&nbsp;</div>';
						  }
						 
						 
						$pimg = getThumb('large');
						$ptitle = get_the_title();
							
						 if(!$sharittop) {
							$workdesc .= '<div class="three columns resdontshow omega sharing">';
				   			$workdesc .= '<div class="sharingbottom tops border-color-works">
											<strong class="sharetitle">'.__('SHARE','dronetv').'</strong>
											<br class="firstclear clear" />
											<div class="buttons">';
							
							$workdesc .= showshareingpost($permalink,$pimg[0], $ptitle,false,1); 
								
							$workdesc .= '</div></div></div>';
						 } 
                        $workdesc .='</div>';
					  ?>
              	
                      <?php 
					  	  /// SHOW PROJECT DESCRIPTION
						  if($descpos!='bottom') {
							echo $workdesc;  
						  }
					  ?>
               
                    
              <br class="clear" />
              
              <div class="postcontent fitvids">
					<?php	
						$s1=0;
						$s2=0;
						$s3=0;
						$portrt = 1;
						$mediatext = unserialize(get_post_meta( $post->ID, 'work-media-text', true ));
						$medialink = unserialize(get_post_meta( $post->ID, 'work-media-link', true ));
						$mediatarget = unserialize(get_post_meta( $post->ID, 'work-media-link-target', true ));
						$mediacaption = unserialize(get_post_meta( $post->ID, 'work-media-caption', true ));
						$mediavideo = unserialize(get_post_meta( $post->ID, 'work-media-video', true ));
						$mediaalign = unserialize(get_post_meta( $post->ID, 'work-media-photoalignment', true ));
						
						
						if(is_array($work_media)) {
							
						
						if($wgallery==2) { 
						
							$mediagallerybg = (get_post_meta( $post->ID, 'work-gallery-bg', true ));
							$mediagallerybgtransparent = (get_post_meta( $post->ID, 'work-gallery-canvas-transparent', true ));
							$mediagallerytr = (get_post_meta( $post->ID, 'work-gallery-transition', true ));
							$mediagallerytrsp = (get_post_meta( $post->ID, 'work-gallery-transition-speed', true ));
							
							if($mediagallerybg=='') {
								$mediagallerybg = '#000';
							}
							if($mediagallerytr=='') {
								$mediagallerytr = 'fade';
							}
							
							echo '<div class="'.$marginclass.' columns alpha forgallerydiv"><a href="#" class="gallery_fullscreen">&nbsp;</a><div class="galleria">';
							
							foreach($work_media as $v) {
							   
							   if($v!='textarea') {
								   
								   if($v=='videoembed') {
									   
									  $imlink = get_template_directory_uri().'/images/playbutton.jpg';
									  $imlink1 = stripslashes($mediavideo[$s1]);
									  $imdesc = '';
									  $s1++; 
									  
								   }else{
									   
									  $imlink = stripslashes($v);
									  $imlink1 = stripslashes($v);
									  $imdesc = @$mediacaption[$s2];
								   	  $s2++;
								   }
									   
									   echo '<a href="'.$imlink1.'"><img src="'.$imlink.'" data-big="'.$imlink.'" data-description="'.stripslashes($imdesc).'"></a>';
									  
							   }
							
							}
							echo '</div></div><br class="clear"><br class="clear">';
						?>	
                        	<style type="text/css">.galleria-container { 
							<?php if($mediagallerybgtransparent==1) { ?>
								background:none;
							<?php }else{ ?>
								background-color:<?php echo $mediagallerybg?>;
							<?php } ?>
							}</style>
						<?php
						
						}else{
						
							foreach($work_media as $v) {
								if($v=='textarea') {
										
									echo '<div class="contenttext '.$marginclass.' columns alpha">'.stripslashes($mediatext[$s3]).'</div>';
									$s3++;
								
								}elseif($v=='videoembed') {
									
									echo '<div class="contentvideos '.$marginclass.' columns alpha">'.stripslashes($mediavideo[$s1]).'</div>';
									$s1++;
									
								}else{
									
									if(isset($mediaalign[$s2]) && $mediaalign[$s2] == 'portrait') {
										
										if($portrt==1) {
											$nstyle = 'alpha offset-by-half';
										}else{
											$nstyle = 'omega';
										}
										
										echo '<div class="contentimages '.$portraitclass.' columns '.$nstyle.'">';
										$portrt++;
										
										$ignoreline=1;
										
										if($portrt==3) { $portrt = 1; unset($ignoreline); } 
										
										
										
									}else{ 
										echo '<div class="contentimages '.$marginclass.' columns alpha">';
									}
									
									
									if($medialink[$s2]!="") {
										echo '<a href="'.$medialink[$s2].'" target="'.$mediatarget[$s2].'">';
									}
			
									echo '<img src="'.stripslashes($v).'" />';
			
									if($medialink[$s2]!="") {
										echo '</a>';
									}
			
									if($mediacaption[$s2]!="") {
										echo '<div class="caption">'.stripslashes($mediacaption[$s2]).'</div>';
									}
			
									echo '</div>';
									$s2++;	
								}
								if(!isset($ignoreline)) { 
									echo '<div class="'.$marginclass.' columns alpha resdontshow"><hr class="border-color-works"></div>';
								}
								unset($ignoreline);
								
							}
							}
					
						}
				?>
                <br class="clear" />
                
		 	</div>     
            
			<?php } /// for password protection ?>
            
            
             		<?php 
						  /// SHOW PROJECT DESCRIPTION
						  if($descpos=='bottom') {
							echo $workdesc;  
							echo '<div class="'.$marginclass.' columns alpha resdontshow"><hr class="border-color-works"></div>';
						  }
						  
						  if(comments_open()) {
							echo '<div class="'.$marginclass.' columns alpha resdontshow">';
								  comments_template(); 
							echo '<hr class="border-color-works"></div>';
						  }
					?> 
            
            
            <?php } ?>
            
            
                    
                    
            <div class="<?php echo $marginclass;?> columns alpha worksbottomnav">
                    <div class="sharingbottom bottoms"> 
                  	<?php if(!of_get_option('md_social_post_disable_bottom') && !post_password_required()) {?>
                    	<div class="resdontshow shr"><strong><?php _e('SHARE : ','dronetv');?></strong></div>
                       <?php echo showshareingpost($permalink,$pimg[0], $ptitle,false); ?>
					<?php } ?>
                    &nbsp;
                    </div>
                        <hr class="resshow border-color-works" /> 
                    <div class="navigate pull-right">
                        <span class="pname"></span> 
                        <a href="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>" data-title="All" title="<?php echo $workstitle;?>" data-type="works" data-token="<?php echo $token?>" class="navigate parent getworks-showmsg gohome">&nbsp;</a>
						<?php if(!empty( $prev_post['ID'] )) { ?>
                        <a href="<?php echo get_permalink($prev_post['ID']); ?>" data-type="works" data-token="<?php echo $token?>" data-id="<?php echo $prev_post['ID']?>" title="<?php echo htmlspecialchars($prev_post['post_title'])?>" class="navigate back getworks getworks-showmsg">&nbsp;</a>
                        <?php } ?>
                        <?php if(!empty( $next_post['ID'] )) { ?>
                        <a href="<?php echo get_permalink($next_post['ID']); ?>" data-type="works" data-token="<?php echo $token?>" data-id="<?php echo $next_post['ID']?>" title="<?php echo htmlspecialchars($next_post['post_title'])?>" class="navigate next getworks getworks-showmsg">&nbsp;</a>
                        <?php } ?>
                    </div>
                </div>
        
                        <br class="clear" />
           
		 </div>     
  </div> 
                        
