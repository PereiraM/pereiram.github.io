<?php
/*
Template Name: Full Width
*/
?>
<?php get_header(); ?>
    
    	
    	<br class="clear" />
        <div class="row fitvids">
        <?php if(!of_get_option('md_page_disable_titles')) { ?>
		<div class="sixteen columns navibg withall border-color" style="margin-bottom:25px;">
            	<h3 style="margin-left:0;"><?php the_title(); ?></h3>
        </div>
        <?php } ?>
         
			<?php 
                if ( post_password_required() ) {
                                    
                    echo '<div class="sixteen columns passprotectpage">';
                    $excerpt = get_the_password_form();
                    echo $excerpt;
                    echo '</div>';
                    
                }else{				
            ?>
                <div class="sixteen columns">
                    <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
                            <?php the_content(); ?>
                    <?php endwhile; ?>
                </div>
            <?php } ?>
                
    	</div>
<?php get_footer(); ?>
	