<?php
/*
Template Name: Blog
*/
?>
<?php get_header(); ?>
<?php
/// SLIDER
$show_slider_blog = of_get_option('md_slider_content_switch_blog');
$slider_blog_content = of_get_option('md_slider_content_blog');

if($show_slider_blog) {
?>
        <div class="sixteen columns sliderdiv">
                <div class="flexslider">
                  <ul class="slides">
                <?php 
						foreach($slider_blog_content as $foo) {
					?>
                    	<li>
                    		<?php if($foo['video']) {?>
                            	<?php echo $foo['video']; ?>
                            <?php }else{ ?>
                    		
							<?php if($foo['link']) {?><a href="<?php echo $foo['link']?>" target="<?php echo $foo['target'] ?>"><?php } ?>
                            	<img src="<?php echo $foo['url'] ?>" alt="<?php echo $foo['title']?>" />
                            <?php if($foo['link']) {?></a><?php } ?>
                            
							<?php if($foo['description']) {?>
                            	<p class="flex-caption"><?php echo $foo['description'] ?></p>
                            <?php } ?>
                            
							<?php }?>
                    	</li>
					<?php } ?>
                  </ul>
                </div>
        </div>
<?php } ?>      
      
      
	<?php
		get_template_part( 'loop', 'index' ); 
	?>

<?php get_footer(); ?>
