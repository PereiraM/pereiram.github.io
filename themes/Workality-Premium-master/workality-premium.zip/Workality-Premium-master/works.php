<?php 
/// POST TYPE SELECTION

global $page_type;
if(!isset($page_type)) {
	$page_type = getCustomPage();
}
global $customtypes;
if(!isset($customtypes)) {
	$customtypes = of_get_option('md_custom_posts');
}

$vartype = $customtypes[$page_type];

$postname = $vartype['title'];
$thumb = $vartype['thumbnail'];
$workstitle = $vartype['plural'];
$categoriestitle = $vartype['categoryname'];
$categoryname = $vartype['title'].'-categories';
$dropdowncategories = $vartype['dropdown'];
$dropdowntitle = $vartype['dropdowntitle'];
$portfoliolink = @$vartype['home_url'];
$works_pagination = intval($vartype['pagination']);
$hideheader = intval($vartype['hideheader']);
$showwithbg = intval($vartype['withbg']);
$showcategory = intval($vartype['showcategory']);
$showtitle = intval($vartype['showtitle']);
$showexcerpt = intval($vartype['showexcerpt']);
$showdate = intval($vartype['showdate']);
$orderby = intval($vartype['orderby']);


if($works_pagination == 0) {
	$works_pagination = -1;
}

	if($works_pagination < 1 && !isset($term)) {
		$catclass1 = 'portfolio-cats-ajax';
		$catclass2 = 'reschange-ajax';
	}else{
		$catclass1 = 'portfolio-cats-regular';
		$catclass2 = 'reschange-regular';
	}


	
	$paged = md_get_page_number();


// GET PORTFOLIO POSTS
$args = array(
	'post_type' => $postname,
	'posts_per_page' => $works_pagination,
	'post_status' => array('publish')
);


/// CHECK CATEGORY
if(isset($term)) { 

	$args = array_merge($args,
		array(
			 $categoryname=>$term,
			'paged' => $paged
		)
	);
	
	$paginated = 1;
}else{
	
	$args = array_merge($args,
		array(
			'paged' => $paged
		)
	);	
	$paginated = 1;
}

if($orderby==1) {
	$args = array_merge($args,
			array(
			'orderby' => 'menu_order',
			'order'=>'asc'
			)
		);
}else{
	$args = array_merge($args,
			array(
			'orderby' => 'post_date',
			'order'=>'desc'
			)
		);
}


query_posts($args);

// FRO BR
$p=1;
$getbr = getThumbRows($thumb);
?>    
<div id="toplinepagination"></div>
	

    <?php 
        if ( post_password_required() ) {
                            
            echo '<div class="sixteen columns passprotectpage">';
            $excerpt = get_the_password_form();
            echo $excerpt;
            echo '</div>';
            
        }else{				
    ?>
    
            
	<?php if($hideheader!=1) {?>
         <div class="columns navibg withall border-color">
            <div class="four columns alpha">
            	<h3><a href="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>"><?php echo $workstitle; ?></a></h3>
            </div>
            
            <div class="twelve columns omega">
            	<div id="portfolio-cats" class="navigate <?php echo $catclass1?>">
                	<hr class="resshow border-color" />
                    <div class="fullnav <?php if($dropdowncategories==1) echo 'dropdown';?>">
                     <div class="menuwrapper">
                     <?php if($dropdowncategories==1) { ?>
                    	<a href="#" class="categoriesdd">
							<?php echo $dropdowntitle; ?>
                            <strong><?php $singlecat = single_cat_title('',false); 
							if($singlecat) { 
								echo ' : ';
								if(function_exists('mb_strtoupper')) { 
									echo mb_strtoupper($singlecat); 
								}else{ 
									echo strtoupper($singlecat); 
								}
							}
							?>
                            </strong>
                            <span class="arrow-down"></span>
                        </a>
                     <?php } ?>   
                        <ul>
                        <?php 
                            // GET CATEGORIES
                            $tp = $categoryname;
                            //$cats = get_terms($tp);
								
							$cats = $wpdb->get_results("SELECT w.term_id, wp.term_taxonomy_id, w.name, w.slug FROM ".$wpdb->terms." w, ".$wpdb->term_taxonomy." wp 
							WHERE wp.term_id=w.term_id AND wp.taxonomy='".esc_sql($categoryname)."' order by w.term_ordering asc, w.name asc", OBJECT);
							
									
	                        $count_cats = count( $cats ); 
                            if ( $count_cats > 0 ) {
                        ?>
                            <li>
                            <a href="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>" data-rel="all" class="activemenu-bg <?php if(!isset($term)) { echo 'selected'; } ?>" data-th="<?php echo $getbr?>" title="<?php echo __("ALL","dronetv");?>"><?php echo __("ALL","dronetv"); ?></a>
                            </li>
                        <?php		
                           foreach ($cats as $catd) { 
                        ?>
                            <li>
                            <a href="<?php echo esc_attr(get_term_link( $catd->slug, $tp )); ?>" class="activemenu-bg <?php if(isset($term) && $catd->slug==$term) { echo 'selected'; } ?>" data-th="<?php echo $getbr?>" data-rel="<?php echo $catd->slug; ?>" title="<?php echo $catd->name; ?>"><?php if(function_exists('mb_strtoupper')) { echo mb_strtoupper($catd->name); }else{ echo strtoupper($catd->name); } ?></a>
                            </li>
                          <?php } ?>
                        <?php } ?>
                        </ul>
                      </div> 
                    </div>
                    <select class="responsiveselect reschange <?php echo $catclass2?> border-color">
                    	<option value="<?php if($portfoliolink) { echo get_permalink($portfoliolink); }else{ echo '#'; } ?>" data-rel="all" selected=""><?php echo $categoriestitle?></option>
                        <?php		
                       foreach ($cats as $catd) { 
                    	?>
                        <option value="<?php echo esc_attr(get_term_link( $catd->slug, $tp )); ?>" data-rel="<?php echo $catd->slug; ?>"><?php echo $catd->name; ?></option>
                    	<?php } ?>
                    </select>
            	</div>
            </div>	
        </div>
     <?php } ?>   
           
			<br class="clear">
            
    <div id="mainworkscontainer">           
        <div id="post-list" class="row">  
            <?php  while ( have_posts() ) : the_post(); ?>	
            <?php  
			
			// THUMBNAIL & CSS CLASS
			
			$cthumbnail = getThumb($thumb); 
			
			//forresponsive
			$getfull = getThumb('large');
			
			// CREATE ARRAYS
			$draught_links = array();
			$draught_links_q = array();
			
			// AJAX TOKEN
			$token = wp_create_nonce("wp_token");

			// POST CATEGORIES
			$categories = "";
			$categories_q = "";
			
			$terms = get_the_terms( $post->ID , $categoryname, 'string' ); 
			
				if ( $terms && ! is_wp_error( $terms ) ) {
					$draught_links = array();
					$draught_links_q = array();
					foreach ( $terms as $term ) {
						$draught_links[] = $term->name;
						$draught_links_q[] = $term->slug;
					}
					$categories = join( ", ", $draught_links );
					$categories_q = join( " ", $draught_links_q );
				}		
			
			/// DECIDE WHICH CATEGORY TO DISPLAY	
			$paste = '';
			if(isset($checkcat)) { 
					if(!in_array($checkcat,$draught_links_q)) { 
						$paste= 'style="display:none"'; 
					}
			}
			
			// RESET TO ARRAYS
			$draught_links = array();
			$draught_links_q = array();
			
			
			/// GET DIRECT LINK OR DEFAULT
			$work_direct_link_active = get_post_meta( $post->ID , 'work-direct-link-activate', true );
			
			if($work_direct_link_active==1) {
				$work_direct_link = get_post_meta( $post->ID , 'work-direct-link', true );
				$work_direct_target = '_blank';
				$work_direct_class = 'golink';
			}else{
				$work_direct_link = get_permalink();
				$work_direct_target = '_self';
				$work_direct_class = 'getworks';
			}
			
			
			?>
                <div class="<?php  echo $cthumbnail[1]; echo " ".$categories_q;  ?> project-item" <?php echo $paste; ?>>
                	<div class="imgdiv">
                    	<a href="<?php echo $work_direct_link ?>" target="<?php echo $work_direct_target?>" class="<?php echo $work_direct_class?>" data-type="<?php echo $postname?>" data-id="<?php echo $post->ID?>" data-token="<?php echo $token?>">
                        <span></span>
						<?php if($cthumbnail[0]) : ?>										
                            <img src="<?php echo $cthumbnail[0];?>" data-small="<?php echo $cthumbnail[0]?>" data-large="<?php echo $getfull[0]?>" title="<?php echo get_the_title()?>" alt="<?php echo get_the_title()?>" />		
                        <?php endif; ?>	
                    	</a>
                	</div>
                   <div class="thumb_large <?php if($showwithbg) echo 'thumbwithbg';?>" <?php if(!$showtitle) { echo 'style="margin-bottom:15px"';}?>>
                   <?php if($showtitle) { ?>
                   <h5><a href="<?php echo $work_direct_link ?>" target="<?php echo $work_direct_target?>" class="<?php echo $work_direct_class?>" data-type="<?php echo $postname?>" data-id="<?php echo $post->ID?>" data-token="<?php echo $token?>"><?php the_title(); ?></a></h5>
 				   <?php } ?>
                                     
                   	  <?php if($showcategory || $showdate) { ?>
				      <span class="category">
                      <?php if($showcategory) echo $categories;?> &nbsp; 
					  <?php 
					  	if($showdate) { 
					 		echo date_i18n(get_option('date_format'),strtotime(get_the_time( get_option('date_format'), $post->ID ))); 
					  	} 
					   ?>
                      </span>
                      <?php } ?>
					  <?php 	  
						  if($showexcerpt) { 
							the_excerpt(); 
						  }
					   ?>
                    </div>  
                   </div>
            <?php if($p==$cthumbnail[3] && $paste=='') { $p=0; echo '<br class="clear rowseperator">'; }?>
			<?php if($paste=='') { $p++; }  ?>
			<?php endwhile; ?>
            
                    
                        <?php 
                        	$pglink = get_paginate_page_links();
                        ?>
                        
            <?php if($pglink) { ?>            
                <br class="clear" />
               <div class="navigation-bottom-works navigation-bottom-ajax border-color">         
               	<?php echo $pglink;?>
               </div>
            <?php } ?>

         </div>     
    
    </div>
    
    <?php } ?>