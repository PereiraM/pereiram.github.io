<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" <?php language_attributes(); ?>> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html <?php language_attributes(); ?>> <!--<![endif]--><head>

	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 */
	global $page, $paged, $post;
	
	if(isset($post->ID)) {
	$page_title = esc_attr(get_post_meta( $post->ID, 'seo-title', true ));
	$descrip = esc_attr(get_post_meta( $post->ID, 'seo-desc', true ));
	$seokeywords = esc_attr(get_post_meta( $post->ID, 'seo-keywords', true ));
	
		if($page_title=="") {
			wp_title( '|', true, 'right' ); 
		}else{
			echo $page_title." | ";
		}
	}else{
		wp_title( '|', true, 'right' );	
	}
	// Add the blog name.
	echo strip_tags(get_bloginfo( 'name' ));
	
	
	
	if(!is_single()) { 
		if(of_get_option('md_header_logo_subtext')) { 
			echo " - ".strip_tags(of_get_option('md_header_logo_subtext')); 
			} 
	}
	
	/// CREATE DESCRIPTION
	if(!isset($descrip) || $descrip=="") {
		if(is_single()) { 
			$post = $wp_query->post;
			$descrip = strip_tags($post->post_content);
			$descrip_more = '';
				if (strlen($descrip) > 155) {
					$descrip = substr($descrip,0,155);
					$descrip_more = ' ...';
				}
			$descrip = str_replace('"', '', $descrip);
			$descrip = str_replace("'", '', $descrip);
			$descripwords = preg_split('/[\n\r\t ]+/', $descrip, -1, PREG_SPLIT_NO_EMPTY);
			array_pop($descripwords);
			$descrip = implode(' ', $descripwords) . $descrip_more; 
		}else{ 
			$descrip = of_get_option('md_header_seo_description');
		}
	}
	
	
	if(isset($seokeywords) && $seokeywords=="") {
		$seokeywords = of_get_option('md_header_seo_keywords');
	}
	  ?></title>
	<meta name="description" content="<?php echo esc_attr($descrip); ?>">
	<meta name="keywords" content="<?php if(isset($seokeywords)) echo ($seokeywords); ?>">
    
	<!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
  <?php 
		/// GET SITE COLORS & GOOGLE FONTS
		$scolors = siteColors();
		
		/// TEXT SHADOW ON/OFF
		$md_disabletextshadow = of_get_option('md_css_disabletextshadow');
		
		if(!$md_disabletextshadow) { $md_tshadow = 'text-shadow:0 1px 0 '.$scolors['textshadow'].'!important;'; } else { $md_tshadow = 'text-shadow:none!important;'; }
  		
		/// FONT SIZE
		$md_body_fontsize = of_get_option('md_body_fontsize');
		if($md_body_fontsize['size']) { $md_bodyfont = $md_body_fontsize['size']; } else { $md_bodyfont = '12px'; }
		
  		/// BG COLOR / BG PATTERN
		$md_bgpattern = $scolors['bgpattern'];
		$md_bgcolor = $scolors['bgcolor'];
		if(!$md_bgcolor) $md_bgcolor ='#fff';
		if($md_bgpattern!='--No Pattern--')  { $md_bgpattern = ' url('. get_template_directory_uri().'/images/bgpatterns/'. $md_bgpattern.')'; }else {  $md_bgpattern= '';}
  ?>  
	<!-- CSS
  ================================================== -->
    <?php 
  	 if(of_get_option('md_css_htmlfont_enable')) { 
	 	$myhtmlfont = of_get_option('md_css_htmlfont');
  	 }else{
    ?>
  <link href='http://fonts.googleapis.com/css?family=<?php echo str_replace(' ','+',$scolors['googlefontbody'])?>:400,700|<?php echo str_replace(' ','+',$scolors['googlefontheader'])?>' rel='stylesheet' type='text/css'>
	<?php
	 }
	?>
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
    <!--[if IE]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!--[if lt IE 9]>
	<link rel="stylesheet" type="text/css" media="all" href="<?php echo get_template_directory_uri()?>/style_ie.css" />
	<![endif]-->
    
    <!--[if gte IE 9]>
	<link rel="stylesheet" type="text/css" media="all" href="<?php echo get_template_directory_uri()?>/style_ie10.css" />
	<![endif]-->
     
    
	<style type="text/css">
	body { 
		font: <?php echo $md_bodyfont ?> <?php if(isset($myhtmlfont)) { echo $myhtmlfont; }else { ?>'<?php echo str_replace('+',' ',$scolors['googlefontbody']);?>', "HelveticaNeue", "Helvetica Neue", Helvetica, Arial, sans-serif<?php } ?>;
		background:<?php echo $md_bgcolor. $md_bgpattern ?> ;
		color:<?php echo $scolors['fontcolor'];?>;
	}
	<?php 
	$hfont = of_get_option('md_header_logo_text_typo');
	if($hfont && !of_get_option('md_header_logo')) {?>
	a.main-logo { 
		font-family:<?php if(isset($myhtmlfont)) { echo $myhtmlfont; }else { ?>'<?php echo str_replace('+',' ',$scolors['googlefontheader']);?>', "HelveticaNeue", "Helvetica Neue", Helvetica, Arial, sans-serif<?php } ?>;
		font-size:<?php echo $hfont['size'];?>!important; 
		<?php if(isset($hfont['color'])) { ?> color:<?php echo $hfont['color']?>!important;<?php } ?> 
	}
	<?php } ?>
	h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a { 
		color:<?php echo $scolors['headingcolor'];?>!important; 
		<?php echo $md_tshadow;?>
		font-family:<?php if(isset($myhtmlfont)) { echo $myhtmlfont; }else { ?>'<?php echo str_replace('+',' ',$scolors['googlefontheader']);?>', "HelveticaNeue", "Helvetica Neue", Helvetica, Arial, sans-serif<?php } ?>;
	}
	.wp-caption, blockquote, .navigation-bottom a, .navigation-bottom-works a, .border-color,.widget_tag_cloud div a { 
	border-color:<?php echo $scolors['bordercolor'];?>!important; border-style:<?php echo $scolors['borderstyle'];?>!important; 
	}
	a { color:<?php echo $scolors['linkcolor'];?>; }
	a:hover, a:focus { color:<?php echo $scolors['linkcoloractive'];?>; }

	.text-shadow { <?php echo $md_tshadow;?> } 
	<?php 
		if(of_get_option('md_main_menu_styling_enable')) {  
		$mnav = of_get_option('md_main_menu_styling');
	?>
	ul.main-nav { font-family:<?php echo $mnav['face']?>; font-size:<?php echo $mnav['size']?>; font-weight:<?php echo $mnav['style']?>; }
	<?php } ?>
	ul.main-nav .current_page_item a, ul.main-nav .current_menu_item a, ul.main-nav li:hover a, .fullnav.dropdown li:hover a { 
		border-color:<?php echo $scolors['linkcolor'];?>!important;
		color:<?php echo $scolors['linkcolor'];?>;
	}
	ul.main-nav ul li, .fullnav.dropdown ul li {
		background-color:<?php echo $scolors['menubg'];?>!important;
	}
	ul.main-nav ul:after, .fullnav.dropdown ul:after {
		border-bottom-color:<?php echo $scolors['menubg'];?>!important;
	}
	ul.main-nav ul li a, .fullnav.dropdown  ul li a { 
		color:<?php echo $scolors['menufont'];?>!important;
	}
	ul.main-nav ul li a:hover, .fullnav.dropdown ul li a:hover { 
		background-color:<?php echo $scolors['menubgactive'];?>!important;
		color:<?php echo $scolors['menufontactive'];?>!important;
	}
	.activemenu-bg, .navigation-bottom-works .current { 
		background-color:<?php echo $scolors['menubg'];?>!important;
		color:<?php echo $scolors['menufont'];?>!important;
	}
	.activemenu-bg:hover, .activemenu-bg.selected { 
		background-color:<?php echo $scolors['menubgactive'];?>!important;
		color:<?php echo$scolors['menufontactive'];?>!important;
	}
	.widget { border-color:<?php echo $scolors['bordercolor'];?>!important; }
	.widget li { border-color:<?php echo $scolors['bordercolor'];?>!important; }
	<?php if(!$md_disabletextshadow) {?>
	.featured img {
		-moz-box-shadow: 0px 0px 2px <?php echo $scolors['textshadow'];?>!important;
		-webkit-box-shadow: 0px 0px 2px <?php echo $scolors['textshadow'];?>!important;
		box-shadow: 0px 0px 2px <?php echo $scolors['textshadow'];?>!important;	
	}
	<?php }else{ ?>
	.featured img {
		-moz-box-shadow:none!important;
		-webkit-box-shadow: none!important;
		box-shadow: none!important;	
	}
	<?php } ?>
	input[type="text"],
	input[type="password"],
	textarea {
		background-color:<?php echo $scolors['formelement'];?>;
		border-color:<?php echo $scolors['formelement'];?>;
	} 
	ul.tabs-content {
		background-color:<?php echo $scolors['menubg'];?>!important;
		color:<?php echo $scolors['menufont'];?>!important;	
	}
	ul.tabs-content {
		background-color:<?php echo $scolors['menubg'];?>!important;
		color:<?php echo $scolors['menufont'];?>!important;	
	}
	dl.tabs dd.active {  
		background-color:<?php echo $scolors['menubg'];?>!important;
		color:<?php echo$scolors['menufont'];?>!important;
	}
	table#wp-calendar { border-color:<?php echo $scolors['bordercolor'];?>; }
	<?php 
		if(of_get_option('md_slider_navigation_dots')==1) {
	?>
	.flex-control-nav {display:none;}
	<?php } ?>
	
	<?php 
		if(of_get_option('md_post_withbg')==1 && of_get_option('md_post_withbg_color')) {
	?>
	div.project-item div.thumb_large.thumbwithbg {
		background-color:<?php echo of_get_option('md_post_withbg_color') ?>;
	}
	<?php		
	    }
	?>
	<?php 
	 //// GET WORKS THUMBNAIL STYLING (IF PAGE-CUSTOM-TYPE IS DEFINED)
	 	global $post;
		if(isset($post)) {
			$chk = get_post_meta( $post->ID, 'page-custom-type', true );
			
			if($chk) { 
				$page_type = getCustomPage();
				$customtypes = of_get_option('md_custom_posts');
				
				$vartype = $customtypes[$page_type];
		
				if($vartype['thumbhover']) {
					$rollcolor = $vartype['thumbhovercolor'];
				}else{
					$rollcolor = 'none';	
				}
				echo 'div.project-item .imgdiv span { 
							background:'. $rollcolor.'!important; 
					  }';
			}
		
		}
	
	?>
	<?php echo of_get_option('md_custom_css')?>
	
	<?php if(of_get_option('md_gallery_caption_placement')=='bottom') { ?>
	 .galleria-info { bottom:60px; top:auto; }
	<?php } ?>
	<?php if(of_get_option('md_gallery_caption_alignment')=='center') { ?>
	.galleria-info-description { text-align:center; }
	<?php } ?>
	.ie10 div.nav-div form button { 
		display:inline-block!important;
		width:40px;
		max-width:40px;
		position:relative;
		top:-1px;
		left:2px;
		height:32px!important;
		border-radius: 5px!important;
	}
	.ie10 .postwraps .sharing .tops div.buttons { display:inline-block}
	.ie10 .postwraps .sharing .tops strong.sharetitle, .postwraps .sharing .tops br.firstclear { display:none; }
	.ie10 .postwraps .sharing .tops { border-width:0; padding:0;}
	</style>
	<?php
		/// PUT WORKS STYLES IF IT IS NOT AJAX CALL
		$getpt = get_post_type();
		if(!empty($getpt) && get_post_type()!='page' && get_post_type()!='post') {
    		workStyles();
	 	} 
	?>	
	<!-- Favicons
	================================================== --> 
    <?php if(of_get_option('md_favicon')) { ?>
    	<link rel="icon" type="image/png" href="<?php echo of_get_option('md_favicon')?>">
    <?php } ?>
	<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri() ?>/images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="<?php echo get_template_directory_uri() ?>/images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="<?php echo get_template_directory_uri() ?>/images/apple-touch-icon-114x114.png">
        
	<!-- RSS
  ================================================== -->
  	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Feed" href="<?php echo home_url(); ?>/rss">
  	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    
    
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	
    <!-- Head End
  ================================================== -->
    <?php wp_head(); ?>
    
    <script type="text/javascript">
		$(function() {
			if (navigator.userAgent.indexOf("MSIE 10") > -1) {
				document.body.classList.add("ie10");
			}
		});
	</script>
    
</head>
 
 <body <?php body_class(); ?>>
	<div class="container">
		<div class="sixteen columns topmargin">
            <div class="six columns alpha">
            <a href="#" class="button navbarbutton pull-right"><i class="icon-reorder menu-icon"></i></a>
				<?php 
                 if(of_get_option('md_header_logo')) { 
                    echo '<a href="'.home_url().'" title="'.get_bloginfo( 'name' ).'"><img src="'.of_get_option('md_header_logo').'" class="" alt="'.get_bloginfo( 'name' ).'"></a>';
                 }elseif(of_get_option('md_header_logo_text')) {
                    echo '<a href="'.home_url().'" class="main-logo" title="drone">'.of_get_option('md_header_logo_text').'</a>';	
                 }else{
					echo '<a href="'.home_url().'" class="main-logo" title="drone">'.get_bloginfo('name').'</a>';
				 }
                 ?>
            </div>
    		<div class="ten columns omega header-right">
            	<div class="nav-div">
                <?php 
				$md_head_search = of_get_option('md_header_disable_search');
				$md_head_subtext = of_get_option('md_header_logo_subtext');
				if(!$md_head_search) : ?>
                <form action="<?php echo get_site_url()?>">
            		<input type="text" name="s" class="medium" value=""><button type="submit"><i class='icon-search'></i></button>
                </form>
                <?php endif; ?>
                
				<?php 
					if($md_head_search) { 
						echo '<div style="margin-top:10px;">';
						wp_nav_menu(array(
                        'theme_location' => 'main_menu',
                        'container' => '',
                        'menu_class' => 'main-nav text-shadow',
                        'before' => '',
                        'fallback_cb' => ''
                    	));
					 	echo '</div>';
						$menushowed=1;
					 } 
				 ?>
                </div>
            </div>
            <br class="clear" />
            <div class="six columns alpha">
				<h6 class="subtext"><?php echo $md_head_subtext; ?></h6>
            </div>
            <?php if(!isset($menushowed)) { ?>
            <div class="ten columns omega header-right">
                    <?php wp_nav_menu(array(
                        'theme_location' => 'main_menu',
                        'container' => '',
                        'menu_class' => 'main-nav text-shadow',
                        'before' => '',
                        'fallback_cb' => ''
                    ));
					?> 
            </div>
            <?php } ?>
            <br class="clear" />
			<hr class="headerbottom border-color" />
		</div>
    <div class="header_contact"></div>
    