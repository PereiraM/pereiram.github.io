<?php
global $wp_query;
$post_obj = $wp_query->get_queried_object();
?>
<?php get_header(); ?>
	
<div id="loadintothis">
	<?php 
		if($post_obj->post_type=='post' || $post_obj->post_type=='attachment') {
			get_template_part( 'loop', 'single' );	
		}else{
			get_template_part( 'works', 'single' );	
		}
	?>
</div>    

<?php get_footer(); ?>
