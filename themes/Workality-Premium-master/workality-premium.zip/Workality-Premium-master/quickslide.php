<?php
		$page = $_REQUEST['pname'];
		$pagetitle = $_REQUEST['ptitle'];
		$p_data = get_page_by_path($page);
		if(!$p_data->ID) { 
		//	echo 0;
			//exit;
		}
		$content = apply_filters('the_content', $p_data->post_content);
		
?> 
 <div class="eight columns">
 	<h5 style="margin-top:15px;"><?php echo $pagetitle?></h5>
 </div>
 <div class="eight columns">
 	<a href="#" onclick="$('.header_contact').slideUp();return false" class="closeit"><i class="icon-remove <?php if(siteIcons()) echo 'icon-white';?>"></i> <?php _e('Close','dronetv');?></a>
 </div>
 <br class="clear" />
      <div class="sixteen columns">
            <hr class="quickslidebottom border-color" />
      </div> 
      
		<div class="sixteen columns">          
			<?php
                echo $content;
            ?>
        </div>
    
        <div class="sixteen columns">
            <hr class="headerbottom border-color" />
        </div>
        
        <br class="clear" />