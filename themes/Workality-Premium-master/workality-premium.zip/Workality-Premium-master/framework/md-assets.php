<?php
/************************************************************
/* Admin Area Scripts & Styles
/************************************************************/

add_action('admin_print_scripts', 'md_admin_scripts');
add_action('admin_print_styles', 'md_admin_styles');


if ( ! function_exists( 'strip_array_indices' ) ) {	
	function strip_array_indices( $ArrayToStrip ) {
		foreach( $ArrayToStrip as $objArrayItem) {
			$NewArray[] =  $objArrayItem;
		}
	 
		return( $NewArray );
	}
}

if ( ! function_exists( 'date_format_php_to_js' ) ) {	
	function date_format_php_to_js( $sFormat ) {
		switch($sFormat) {
			case 'F j, Y':
				return( 'MM dd, yy' );
			break;
			case 'Y/m/d':
				return( 'yy/mm/dd' );
			break;
			case 'm/d/Y':
				return( 'mm/dd/yy' );
			break;
			case 'd/m/Y':
				return( 'dd/mm/yy' );
			break;
		}
	}
}

if ( ! function_exists( 'md_admin_scripts' ) ) {			
	function md_admin_scripts() {
				
				global $pagenow, $current_screen, $post, $wp_locale;
				
				if (($pagenow=="post.php" || $pagenow=="post-new.php")) {
					
				/***************************************
				/* SCRIPTS
				/***************************************/
				//add the jQuery UI elements shipped with WP
				
				/// upload scripts
				wp_enqueue_script( 'media-upload' );
				wp_enqueue_script(
					'upload-js', 
					get_template_directory_uri().'/framework/field_upload.js', 
					array('jquery', 'thickbox', 'media-upload','jquery-ui-core', 'jquery-ui-datepicker'),
					time(),
					true
				);
				wp_localize_script('upload-js', 'wpurl', array( 'siteurl' => ADMIN_IMG_DIRECTORY ));
				
				wp_enqueue_style('thickbox');
				
				wp_enqueue_style('color-picker', get_template_directory_uri() . '/framework/options/assets/css/colorpicker.css');
				
				}
				
	}
}
	

if ( ! function_exists( 'md_admin_styles' ) ) {	
	function md_admin_styles() {
				global $pagenow, $current_screen;
				
				if (($pagenow=="post.php" || $pagenow=="post-new.php")) {
				/***************************************
				/* STYLES
				/***************************************/
				wp_enqueue_style( 'thickbox' ); /// upload
				wp_enqueue_style( 'custom', get_template_directory_uri() . '/framework/css/custom-fields.css' ); /// custom styles
				wp_enqueue_style( 'jquery-ui-css', get_template_directory_uri() . '/framework/css/jquery-ui-aristo/aristo.css' ); /// date picker
				wp_enqueue_script('color-picker-js', get_template_directory_uri() .'/framework/options/assets/js/colorpicker.js', array('jquery'));
				}
	}
}

/************************************************************
/* wp_head() Front-End Scripts & Styles
/************************************************************/

add_action( 'wp_enqueue_scripts', 'md_add_wphead'); 
add_action( 'wp_footer', 'md_add_footer' ); 


if ( ! function_exists( 'md_add_wphead' ) ) {
	function md_add_wphead() {
		
		// Modernizr
		wp_register_script( 'modernizr', get_template_directory_uri() . '/js/modernizr.js' );
		wp_enqueue_script( 'modernizr' );
		
		// JQuery (Remove bundle ver. and include new)
		wp_deregister_script( 'jquery' );
		wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery-1.8.2.min.js' );
		wp_enqueue_script( 'jquery' );
		
		// INCLUDE JS
		wp_register_script( 'include', get_template_directory_uri() . '/js/include.js');
		wp_enqueue_script( 'include' );
			
		wp_register_script( 'galleria', get_template_directory_uri() . '/js/galleria-1.2.9.min.js');
		wp_enqueue_script( 'galleria' );
		
		
		?>
        <script type="text/javascript">// <![CDATA[
			if( window.devicePixelRatio !== undefined ) document.cookie = 'devicePixelRatio = ' + window.devicePixelRatio;
		// ]]></script>
        <?php
		
			
	}  
}



if ( ! function_exists( 'md_add_footer' ) ) {
	function md_add_footer() {
		global $add_the_googlemap;
		global $add_the_contactform;
	 
		
			wp_register_script( 'JQ-gmap-api', 'http://maps.google.com/maps/api/js?sensor=false');	
			wp_register_script( 'gmap-main-script', get_template_directory_uri() . '/js/jquery.gmap.min.js');
			wp_enqueue_script( 'JQ-gmap-api' );
			wp_enqueue_script( 'gmap-main-script' );
		
		
			wp_register_script( 'pageslide', get_template_directory_uri() . '/js/jquery.pageslide.min.js');
			wp_enqueue_script( 'pageslide' );
	
			wp_register_script( 'contact-realperson', get_template_directory_uri() . '/js/jquery.realperson.min.js');
			wp_enqueue_script( 'contact-realperson' );
			
			wp_register_script( 'contact-validate', get_template_directory_uri() . '/js/jquery.validate.js');
			wp_enqueue_script( 'contact-validate' );
		
			
			//wp_register_script( 'respond', get_template_directory_uri() . '/js/respond.min.js');
			//wp_enqueue_script( 'respond' );
			
			wp_register_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js');
			wp_enqueue_script( 'flexslider' );
			
			
		// MASTER JS
		wp_register_script( 'master', get_template_directory_uri() . '/js/master.js');
		wp_enqueue_script( 'master' );
		
		
		if(of_get_option('md_master_ajax_disable')) { 
			$wajax = 0;
		}else{
			$wajax = 1;	
		}
		
		
		// SLIDER DURATION
		if(of_get_option('md_slider_duration')) { $fduration = of_get_option('md_slider_duration');}else{ $fduration = '7000'; }
		if(of_get_option('md_slider_animation')) { $fanimation = of_get_option('md_slider_animation');}else{ $fanimation = 'slide'; }
		if(of_get_option('md_slider_animation_speed')) { $fanimationspeed = of_get_option('md_slider_animation_speed');}else{ $fanimationspeed = 500; }
		
		if(of_get_option('md_gallery_transition')) { $gal_tr = of_get_option('md_gallery_transition');}else{ $gal_tr = 'fade'; }
		if(of_get_option('md_gallery_transition_speed')) { $gal_tr_speed = of_get_option('md_gallery_transition_speed');}else{ $gal_tr_speed = 500; }
		if(of_get_option('md_gallery_crop')) { $gal_crop = 'true'; }else{ $gal_crop = 'false'; }
		
		if(of_get_option('md_gallery_slideshow_autostart')==1) { 
			$gal_slide_speed = of_get_option('md_gallery_slideshow_speed');
		}else{ 
			$gal_slide_speed = 10000000000; 
		}
		
		
		$ajaxvararr = array(
			'flex'=>$fduration,
			'flexanimation'=>$fanimation,
			'flexanimationspeed'=>$fanimationspeed,
			'gallery_transition'=>$gal_tr,
			'gallery_transition_speed'=>$gal_tr_speed,
			'gallery_slideshow_speed'=>$gal_slide_speed,
			'gallery_crop'=>$gal_crop,
			'withajax'=>$wajax,
			'themeurl'=>get_template_directory_uri(),
			'ajax'=>admin_url( 'admin-ajax.php')
		);
		
		wp_localize_script('master', 'mdajaxurl', $ajaxvararr);	
		
	}  
}


?>