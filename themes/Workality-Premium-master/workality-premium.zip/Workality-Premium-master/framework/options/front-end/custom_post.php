   <!--[if lt IE 9]>
	<link rel="stylesheet" type="text/css" media="all" href="<?php echo ADMIN_DIR; ?>/assets/css/font-awesome-ie7.min.css" />
	<![endif]-->
    
<div class="wrap" id="of_container">

	<div id="of-popup-save" class="of-save-popup">
		<div class="of-save-save">Options Updated</div>
	</div>
	
	<div id="of-popup-reset" class="of-save-popup">
		<div class="of-save-reset">Options Reset</div>
	</div>
	
	<div id="of-popup-fail" class="of-save-popup">
		<div class="of-save-fail">Error!</div>
	</div>
	
	<span style="display: none;" id="hooks"><?php echo json_encode(of_get_header_classes_array()); ?></span>
	<input type="hidden" id="reset" value="<?php if(isset($_REQUEST['reset'])) echo $_REQUEST['reset']; ?>" />
	<input type="hidden" id="security" name="security" value="<?php echo wp_create_nonce('of_ajax_nonce'); ?>" />

	<form id="of_form" method="post" action="<?php echo esc_attr( $_SERVER['REQUEST_URI'] ) ?>" enctype="multipart/form-data" >
	
		<div id="header">
		
			<div class="logo">
				<h2><?php echo THEMENAME; ?></h2>
				<span><?php echo ('v'. THEMEVERSION); ?></span>
			</div>
		
			<div id="js-warning">Warning- This options panel will not work properly without javascript!</div>
			<div class="icon-option"></div>
			<div class="clear"></div>
		
    	</div>

		<div id="info_bar">
			
            <strong style="float:left; color:#f0f0f0; font-size:13px; margin:5px 0 0 15px; font-weight:normal">
            	CUSTOM POST GENERATOR
            </strong>
            
            		
			<img style="display:none" src="<?php echo ADMIN_DIR; ?>assets/images/loading-bottom.gif" class="ajax-loading-img ajax-loading-img-bottom" alt="Working..." />

			<button id="of_save" type="button" class="button-primary">
				<?php _e('Save All Changes','dronetv');?>
			</button>
			
		</div><!--.info_bar--> 	
		
		<div id="main">
        
            
            <div id="of-nav">
              <ul>
                 <li class="headersettings">
                 	<a title="Header Settings" href="#of-option-headersettings"><i class="icon-file-alt"></i> Header Settings</a>
                 </li>
              </ul>
        	</div>
            
            <div id="content">
            	<div class="group" id="of-option-blogposts" style="display: block;">
                	<h2>Blog Posts</h2>
				
                     <div id="section-md_works_title" class="section section-text ">
                        <h3 class="heading">Works Page Title</h3>
                            <div class="option">
                                <div class="controls">
                                	<input class="of-input" name="md_works_title" id="md_works_title" type="text" value="Works2">
                                </div>
                                <div class="explain">
                                    Your default portfolio title is "Works" regardless to your works page title.
                                </div>
                                <div class="clear"></div>
                            </div>
                       </div>
                </div>


            </div>
            
            	 
                   
			<div class="clear"></div>
			
		</div>
		
		<div class="save_bar"> 
		
			<img style="display:none" src="<?php echo ADMIN_DIR; ?>assets/images/loading-bottom.gif" class="ajax-loading-img ajax-loading-img-bottom" alt="Working..." />
			<button id ="of_save" type="button" class="button-primary"><?php _e('Save All Changes','dronetv');?></button>			
			
		</div><!--.save_bar--> 
 
	</form>
	
	<div style="clear:both;"></div>

</div><!--wrap-->