<?php

add_action('init','of_options');

if (!function_exists('of_options'))
{
	function of_options()
	{
		//Access the WordPress Categories via an Array
		$of_categories = array();  
		$of_categories_obj = get_categories('hide_empty=0');
		foreach ($of_categories_obj as $of_cat) {
		    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
		$categories_tmp = array_unshift($of_categories, "Select a category:");    
	       
		//Access the WordPress Pages via an Array
		$of_pages = array();
		$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
		foreach ($of_pages_obj as $of_page) {
		    $of_pages[$of_page->ID] = $of_page->post_name; }
		$of_pages_tmp = array_unshift($of_pages, "Select a page:");       
	
		//Testing 
		$of_options_select = array("one","two","three","four","five"); 
		$of_options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five");
		
		//Sample Homepage blocks for the layout manager (sorter)
		$of_options_homepage_blocks = array
		( 
			"disabled" => array (
				"placebo" 		=> "placebo", //REQUIRED!
				"block_one"		=> "Block One",
				"block_two"		=> "Block Two",
				"block_three"	=> "Block Three",
			), 
			"enabled" => array (
				"placebo" => "placebo", //REQUIRED!
				"block_four"	=> "Block Four",
			),
		);


		//Stylesheets Reader
		$alt_stylesheet_path = LAYOUT_PATH;
		$alt_stylesheets = array();
		
		if ( is_dir($alt_stylesheet_path) ) 
		{
		    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) 
		    { 
		        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) 
		        {
		            if(stristr($alt_stylesheet_file, ".css") !== false)
		            {
		                $alt_stylesheets[] = $alt_stylesheet_file;
		            }
		        }    
		    }
		}


		//Background Images Reader
		$bg_images_path = STYLESHEETPATH. '/images/bg/'; // change this to where you store your bg images
		$bg_images_url = get_bloginfo('template_url').'/images/bg/'; // change this to where you store your bg images
		$bg_images = array();
		
		if ( is_dir($bg_images_path) ) {
		    if ($bg_images_dir = opendir($bg_images_path) ) { 
		        while ( ($bg_images_file = readdir($bg_images_dir)) !== false ) {
		            if(stristr($bg_images_file, ".png") !== false || stristr($bg_images_file, ".jpg") !== false) {
		                $bg_images[] = $bg_images_url . $bg_images_file;
		            }
		        }    
		    }
		}
		

		/*-----------------------------------------------------------------------------------*/
		/* TO DO: Add options/functions that use these */
		/*-----------------------------------------------------------------------------------*/
		
		//More Options
		$uploads_arr = wp_upload_dir();
		$all_uploads_path = $uploads_arr['path'];
		$all_uploads = get_option('of_uploads');
		$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
		$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
		$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");
		
		// Image Alignment radio box
		$of_options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 
		
		// Image Links to Options
		$of_options_image_link_to = array("image" => "The Image","post" => "The Post"); 




/// GET BG PATTERNS
if ($handle = opendir(THEME_FILEPATH.'/images/bgpatterns')) {
	$bgpatterns = array('--No Pattern--');
    while (false !== ($entry = readdir($handle))) {
		$ext = pathinfo($entry, PATHINFO_EXTENSION);
		if($ext=="png" || $ext=="jpeg" || $ext=="jpg" || $ext=="gif")
        array_push($bgpatterns,$entry);
    }
    closedir($handle);
}



/*-----------------------------------------------------------------------------------*/
/* The Options Array */
/*-----------------------------------------------------------------------------------*/

// Set the Options Array
global $of_options;
$of_options = array();



						
									
$of_options[] = array("name" => "Custom Posts",
					"type" => "heading",
					"icon"=>'magic');
						

				
$of_options[] = array(
					'id' => 'md_custom_posts',
					'type' => 'customposts',
					'name' => 'Custom Post Type Generator', 
					'desc' => __('This is your Custom Post Type generator. <br><br>To create a new post type, click on the <strong>Create New Post Type</strong> button and fill out the form. Please note that all fields are required on <strong>Step 2 and Step 3</strong>.<br><br>By default, Workality comes with <strong>works</strong> custom post type and it cannot be deleted but values can be changed.', ''),
					'std' => ''// 1 = on | 0 = off
				);
			
								
										
								
$of_options[] = array("name" => "Posts Ordering",
					"type" => "heading",
					"icon"=>'magic');
						

				
$of_options[] = array(
					'id' => 'md_custom_posts_ordering',
					'type' => 'custompostsordering',
					'name' => 'Custom Posts Ordering', 
					'desc' => __('You can re-order custom posts via drag&drop. Once you finished re-ordering, click on the SAVE ALL CHANGES button to save.', ''),
					'std' => ''// 1 = on | 0 = off
				);
			
						
								
$of_options[] = array("name" => "Category Ordering",
					"type" => "heading",
					"icon"=>'magic');
					
					
$of_options[] = array(
					'id' => 'md_custom_taxonomy_ordering',
					'type' => 'customtaxonomysordering',
					'name' => 'Category Ordering', 
					'desc' => __('You can re-order custom posts via drag&drop. Once you finished re-ordering, click on the SAVE ALL CHANGES button to save.', ''),
					'std' => ''// 1 = on | 0 = off
				);
			
		
	
$of_options[] = array( "name" => "Blog Posts",
					"type" => "heading",
					"icon"=>'th-large');
	
$of_options[] = 		array(
						'id' => 'md_theblog_title',
						'type' => 'text',
						'name' => __('Blog Page Title', ''),
						'desc' => __('Your default blog title is "Blog" regardless to your blog page title. This option allows you to change default title as you wish. <br><br>Leave it blank for the default.', ''),
						'std' => 'Blog'
						);


$of_options[] = array(
					'id' => 'md_theblog_homelink',
					'type' => 'pagesselect',
					'name' => __('Blog Home Page', ''),
					'desc' => __('Select your "blog" home page', ''),
					'std' => 'default' 
				);

$of_options[] =			array(
						'id' => 'md_theblog_limit',
						'name' => __('Pagination Limit', ''), 
						'desc' => __('Set pagination limit of blog overview page. Default is 10', ''),
						"type" => "selectkey",
						'std' => '10',
						"options" => array(
									0=>'Unlimited',
									1=>1,
									2=>2,
									3=>3,
									4=>4,
									5=>5,
									6=>6,
									7=>7,
									8=>8,
									9=>9,
									10=>10,
									11=>11,
									12=>12,
									13=>13,
									14=>14,
									15=>15,
									16=>16,
									17=>17,
									18=>18,
									19=>19,
									20=>20,
									21=>21,
									22=>22,
									23=>23,
									24=>24,
									25=>25,
									26=>26,
									27=>27,
									28=>28,
									29=>29,
									30=>30
									));  	
						
						
$of_options[] =			array(
						'id' => 'md_theblog_categories_dropdown',
						'type' => 'checkbox',
						'name' => 'Display Blog Category Filters as Dropdown Menu', 
						'desc' => __('By default, category filters in Blog page are displayed as links. This option allows you to show category filters as dropdown menu, in case you have high quantity of categories.', ''),
						'std' => '0'// 1 = on | 0 = off
						);
																							

$of_options[] = 		array(
						'id' => 'md_theblog_categories_title',
						'type' => 'text',
						'name' => __('Categories Filter Dropdown Title', ''),
						'desc' => __('This title will be shown if the category dropdown is activated. <br><br>Default title is CATEGORY', ''),
						'std' => 'CATEGORY'
						);
						
											
$of_options[] =			array(
						'id' => 'md_posts_sidebar',
						'type' => 'checkbox',
						'name' => 'Blog Siderbars', 
						'desc' => __('Disable sidebar in blog posts', ''),
						'std' => '0'// 1 = on | 0 = off
						);
						
					
$of_options[] =			array(
						'id' => 'md_posts_sidebar_single',
						'type' => 'checkbox',
						'name' => '', 
						'desc' => __('Disable sidebar in single post', ''),
						'std' => '0'// 1 = on | 0 = off
						);

$of_options[] = 		array(
						'id' => 'md_post_show_category',
						'type' => 'checkbox',
						'name' => 'Blog Posts', 
						'desc' => __('Show Category', ''),
						'std' => '1'// 1 = on | 0 = off
						);
$of_options[] =			array(
						'id' => 'md_post_show_date',
						'type' => 'checkbox',
						'name' => '', 
						'desc' => __('Show Date', ''),
						'std' => '1'// 1 = on | 0 = off
						);

$of_options[] = 		array(
						'id' => 'md_post_show_author',
						'type' => 'checkbox',
						'name' => '',
						'desc' => __('Show Author info', ''), 
						'std' => '1'// 1 = on | 0 = off
						);	
$of_options[] = 		array(
						'id' => 'md_post_show_comments',
						'type' => 'checkbox',
						'name' => '', 
						'desc' => __('Show Comment Count', ''),
						'std' => '1'// 1 = on | 0 = off
						);



$of_options[] = 		array(
						'id' => 'md_post_show_works_category',
						'type' => 'checkbox',
						'name' => 'Works Thumnails', 
						'desc' => __('Show Category', ''),
						'std' => '0'// 1 = on | 0 = off
						);
$of_options[] =			array(
						'id' => 'md_post_show_works_date',
						'type' => 'checkbox',
						'name' => '', 
						'desc' => __('Show Date', ''),
						'std' => '0'// 1 = on | 0 = off
						);


		
						
					
$of_options[] = array( "name" => "Sliders",
					"type" => "heading",
					"icon" =>'desktop');	
					
		

	@$mydta = get_option(OPTIONS);
	
	if(!is_array($mydta['md_custom_posts'])) { 
		$mydta['md_custom_posts']['works']['plural'] = "Works";
		$mydta['md_custom_posts']['works']['title'] = "works";
	}
	
	$mydta['md_custom_posts']['blog']['plural'] = "Blog";
	$mydta['md_custom_posts']['blog']['title'] = "blog";	
			
	
	foreach($mydta['md_custom_posts'] as $foo) {					
								

			$of_options[] =	array(
							'id' => 'md_slider_content_switch_'.$foo['title'],
							'type' => 'checkbox',
							'name' => __('Slider for '.$foo['plural'], ''), 
							'desc' => __('', ''),
							'std' => '0'// 1 = on | 0 = off
							);
															
			$of_options[] = array( "name" => "",
							"desc" => "Unlimited slider with drag and drop sortings. <br>Recommended image size is <strong>940px</strong> width with any height. Videos will be re-scaled regardless to their size values.",
							"id" => "md_slider_content_".seoUrl($foo['title']),
							"std" => "",
							"type" => "slider");
			
	 }
	
	

$of_options[] = array( "name" => "Hide Slider Navigation Dots",
						"desc" => "Allows you to hide navigation dots bottom of the slider",
						"id" => "md_slider_navigation_dots",
						"std" => "0",
						"type" => "checkbox"); 
												
$of_options[] =			array(
						'id' => 'md_slider_animation',
						'name' => __('Slider animation type', ''), 
						'desc' => __('', ''),
						"type" => "select",
						'std' => 'slide',
						"options" => array('slide','fade'));  	


$of_options[] = 		array(
						'id' => 'md_slider_animation_speed',
						'type' => 'text',
						'name' => __('Animation Speed', ''),
						'desc' => __('Transition/animation speed. in milliseconds. E.g 1000 (for 1 second)', ''),
						'std' => '500'
						);
							

$of_options[] = 		array(
						'id' => 'md_slider_duration',
						'type' => 'text',
						'name' => __('Slideshow Speed', ''),
						'desc' => __('Set the speed of the slideshow cycling, in milliseconds. E.g 7000 (for 7 seconds)', ''),
						'std' => '7000'
						);
								
	
	
				
$of_options[] = array( "name" => "Gallery",
					"type" => "heading",
					"icon" =>'desktop');	
						


$of_options[] = array( "name" => "",
                    "id" => "md_gallery_info",
                    "std" => "Following settings will be applied to custom post type galleries",
                    "type" => "info",
					"desc" => '',
					);
				

$of_options[] = array( "name" =>  "Gallery BG Color",
					"desc" => "",
					"id" => "md_gallery_defbg",
					"std" => "#000",
					"type" => "color");	
									
					
$of_options[] = 		array(
						'id' => 'md_gallery_transition',
						'type' => 'selectkey',
						'name' => __('Transition Type', ''),
						'desc' => __('', ''),
						'std' => 'fade',
						'options'=>array('fade'=>'Fade', 'flash'=>'Flash', 'pulse'=>'Pulse', 'slide'=>'Slide', 'fadeslide'=>'Fade Slide')
						);
						

$of_options[] = 		array(
						'id' => 'md_gallery_transition_speed',
						'type' => 'selectkey',
						'name' => __('Transition Speed', ''),
						'desc' => __('', ''),
						'std' => '500',
						'options'=>array('100'=>'0.1 sec', '500'=>'0.5 msec', '1000'=>'1 sec', '2000'=>'2 sec', '3000'=>'3 Sec', '5000'=>'5 Sec')
						);
		
$of_options[] = 		array(
						'id' => 'md_gallery_slideshow_speed',
						'type' => 'text',
						'name' => __('Slideshow Speed', ''),
						'desc' => __('Set the speed of the slideshow cycling, in milliseconds. E.g 7000 (for 7 seconds)', ''),
						'std' => '7000'
						);												
						

$of_options[] = array( "name" => "Slideshow Autostart",
						"desc" => "",
						"id" => "md_gallery_slideshow_autostart",
						"std" => "0",
						"type" => "checkbox"); 
									
									
$of_options[] = array( "name" => "Crop Images",
						"desc" => "This option allows you to display your images in full width regardless to their height.",
						"id" => "md_gallery_crop",
						"std" => "0",
						"type" => "checkbox"); 
									
$of_options[] = 		array(
						'id' => 'md_gallery_caption_placement',
						'type' => 'selectkey',
						'name' => __('Caption Placement', ''),
						'desc' => __('', ''),
						'std' => 'top',
						'options'=>array('top'=>'Top', 'bottom'=>'Bottom')
						);
											
								
$of_options[] = 		array(
						'id' => 'md_gallery_caption_alignment',
						'type' => 'selectkey',
						'name' => __('Caption Text Alignment', ''),
						'desc' => __('', ''),
						'std' => 'left',
						'options'=>array('left'=>'Left', 'center'=>'Center')
						);								
																							


$of_options[] = array( "name" => "Posts Sharing",
					"type" => "heading",
					"icon" =>'share');
							

$of_options[] = array( "name" => "Disable Top Share Buttons in Works Posts",
									"desc" => "This option will disable all share buttons on top right of the page",
									"id" => "md_social_post_disable_top",
									"std" => "0",
									"type" => "checkbox"); 
									
$of_options[] = array( "name" => "Disable Bottom Share Buttons in Works&Blog Posts",
									"desc" => "This option will disable all share buttons on bottom left of the page",
									"id" => "md_social_post_disable_bottom",
									"std" => "0",
									"type" => "checkbox"); 
													
														
$of_options[] = array( "name" => "Show Share Buttons in Posts",
									"desc" => "Facebook",
									"id" => "md_social_post_facebook",
									"std" => "1",
									"type" => "checkbox"); 																	
$of_options[] = array( "name" => "",
					"desc" => "Twitter",
					"id" => "md_social_post_twitter",
					"std" => "1",
					"type" => "checkbox");
					
$of_options[] = array( "name" => "",
					"desc" => "Google +",
					"id" => "md_social_post_googleplus",
					"std" => "0",
					"type" => "checkbox"); 	
										
$of_options[] = array( "name" => "",
					"desc" => "Pinterest",
					"id" => "md_social_post_pinterest",
					"std" => "0",
					"type" => "checkbox"); 
					
$of_options[] = array( "name" => "",
					"desc" => "Tumblr",
					"id" => "md_social_post_tumblr",
					"std" => "0",
					"type" => "checkbox"); 	


$of_options[] = array( "name" => "",
					"desc" => "Vkontakte",
					"id" => "md_social_post_vkshare",
					"std" => "0",
					"type" => "checkbox"); 	
	
	
	
	
								
													
$of_options[] = array( "name" => "Header Settings",
					"type" => "heading",
					"icon" =>'file-alt'
					);
	
										
$of_options[] =   		array(
						'id' => 'md_header_logo',
						'type' => 'upload',
						'name' => __('Site Logo', ''), 
						'desc' => __('Upload your logo', ''),
						'std'=>''
						);
						
$of_options[] =   		array(
						'id' => 'md_header_logo_text',
						'type' => 'text',
						'name' => __('Site Logo Text', ''),
						'desc' => __('You may prefer to use this text instead of your logo image. If logo image is present, this text will be ignored.', ''),
						'std' => get_bloginfo('name')
						);
	
$of_options[] = array( "name" => "Site Logo Size/Color",
					"desc" => "",
					"id" => "md_header_logo_text_typo",
					"std" => array('size' => '48px','color' => '#000'),
					"type" => "typography");  


$of_options[] = 		array(
						'id' => 'md_header_logo_subtext',
						'type' => 'text',
						'name' => __('Site Logo Tagline', ''),
						'desc' => __('This text will be shown below your logo', ''),
						'std' => ''
						);


$of_options[] =   		array(
						'id' => 'md_favicon',
						'type' => 'upload',
						'name' => __('Favicon', ''), 
						'desc' => __('Upload PNG format. Recommended size is 64px X 64px', ''),
						'std'=>''
						);
	

$of_options[] =			array(
						'id' => 'md_main_menu_styling',
						'name' => __('Main Menu Styling', ''),
						'desc'=> __('This option allows you to override the styling of main menu.',''),
						"std" => array('size' => '13px','face' => 'Arial','style'=>'bold'),
						"type" => "typography"
						);	
						

$of_options[] =			array(
						'id' => 'md_main_menu_styling_enable',
						'type' => 'checkbox',
						'name' => __('', ''), 
						'desc' => __('Activate this option in order to use styles above for the main menu', ''),
						'std' => '0'// 1 = on | 0 = off
						);	

						
$of_options[] =			array(
						'id' => 'md_header_disable_search',
						'type' => 'checkbox',
						'name' => __('Disable Search Bar on the header', ''), 
						'desc' => __('', ''),
						'std' => '0'// 1 = on | 0 = off
						);
	
$of_options[] =			array(
						'id' => 'md_page_disable_titles',
						'type' => 'checkbox',
						'name' => __('Disable Default Page / Full Width Page Header/Title', ''), 
						'desc' => __('', ''),
						'std' => '0'// 1 = on | 0 = off
						);	

$of_options[] =			array(
						'id' => 'md_all_titles_disable',
						'type' => 'checkbox',
						'name' => __('Disable Works and Blog page Header/Title', ''), 
						'desc' => __('Use this option in order to remove works and blog page headers. Please note that the category filters and page navigation shortcuts will also be removed if you activate this option', ''),
						'std' => '0'// 1 = on | 0 = off
						);	

																		
			
			
$of_options[] = array( "name" => "Styling Options",
					"type" => "heading",
					"icon"=>'edit');

					
$of_options[] =   array(
						'id' => 'md_css_presets',
						'type' => 'images',
						'name' => __('Color Presets', ''), 
						'desc' => __('You can select custom in order to create your color settings', ''),
						'options' => array(
										'light' => ADMIN_IMG_DIRECTORY . 'preset1.png',
										'gray' => ADMIN_IMG_DIRECTORY . 'preset2.png',
										'dark' => ADMIN_IMG_DIRECTORY . 'preset3.png',
										'custom' => ADMIN_IMG_DIRECTORY . 'preset4.png',
									 ),
						'std' => 'gray',
          				"folds" => 1,
						);
						
          
$of_options[] = array( "name" =>  "Colors",
					"desc" => "Heading Color",
					"id" => "md_css_heading",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");
					
$of_options[] =  array( "name" =>  "",
					"desc" => "Text Color",
					"id" => "md_css_fontcolor",
					"display"=>'presethidden',
					"std" => "#bbb",
					"type" => "color"); 
					
$of_options[] = array( "name" =>  "",
					"desc" => "Link Color",
					"id" => "md_css_linkcolor",
					"display"=>'presethidden',
					"std" => "#bbb",
					"type" => "color");
$of_options[] = array( "name" =>  "",
					"desc" => "Link Active Color",
					"id" => "md_css_linkcolorhover",
					"display"=>'presethidden',
					"std" => "#bbb",
					"type" => "color");					
					
$of_options[] = array( "name" =>  "",
					"desc" => "Border Color",
					"id" => "md_css_bordercolor",
					"display"=>'presethidden',
					"std" => "#bbb",
					"type" => "color");
	
				
$of_options[] = array( "name" =>  "",
					"desc" => "Text Shadow Color",
					"id" => "md_css_textshadow",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");
							
$of_options[] = array( "name" =>  "",
					"desc" => "Category&amp;Dropdown Menu BG",
					"id" => "md_css_activemenubg",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");	
									
$of_options[] = array( "name" =>  "",
					"desc" => "Category&amp;Dropdown Menu BG Active",
					"id" => "md_css_activemenubg_selected",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");	
$of_options[] = array( "name" =>  "",
					"desc" => "Category&amp;Dropdown Menu TEXT Color",
					"id" => "md_css_activemenucolor",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");	
					
$of_options[] = array( "name" =>  "",
					"desc" => "Category&amp;Dropdown Menu TEXT Color Active",
					"id" => "md_css_activemenucolor_selected",
					"display"=>'presethidden',
					"std" => "#333",
					"type" => "color");						
							
					
$of_options[] = array( "name" =>  "",
					"desc" => "Form Elements BG",
					"id" => "md_css_formelement",
					"display"=>'presethidden',
					"std" => "#bbb",
					"type" => "color");
					
						
$of_options[] = array(
					'name' => 'Show white icons', 
					'desc' => 'Click this option in order to get white icons. Default icons are black',
					'id' => 'md_css_whiteicons',
					"display"=>'presethidden',
					'type' => 'checkbox',
					'std' => '0'
					);
					

$of_options[] = array( "name" => "BG Patterns",
				"desc" => '<strong>BG Pattern Select</strong><br>You can put new patterns into <strong>"images/bgpatterns"</strong> folder. They will be added to the BG patterns list automatically. <br><a href="http://subtlepatterns.com" target="_blank">http://subtlepatterns.com</a>',
				"id" => "md_css_bgpattern",
				"std" => "bedge_grunge.jpg",
				"type" => "select",
				"bgpatterns" => 1, 
				"options" => $bgpatterns); 
				
$of_options[] = array(
				'name' => 'BG Color', 
				'desc' => 'Change background color. <br>This setting will be ignored unless you check "--No Pattern--" option in BG patterns above',
				'id' => 'md_css_mainbgcolor',
				'type' => 'color',
				'std' => '0'
				);	
			

$of_options[] = array( "name" => "Border Type",
				"desc" => '',
				"id" => "md_css_borderstyle",
				"std" => "solid",
				"type" => "select", 
				"options" => array('solid','dotted','dashed')); 
				
																
$of_options[] = array(
					'name' => 'Disable Text Shadow', 
					'desc' => 'Text shadow effect is applied specific title and body elements in this theme. Activate this option in order to disable shadows.',
					'id' => 'md_css_disabletextshadow',
					'type' => 'checkbox',
					'std' => '0'
					);
					
					
													
$of_options[] = array( "name" => "Fonts",
					"type" => "heading",
					"icon"=>'font');
	
						
$of_options[] = array(
						'id' => 'md_css_googlefont_header',
						'type' => 'text',
						'name' => __('Header Font', ''),
						'desc' => __('You can select header font via dropdown menu. <strong>500+</strong> google fonts are ready to use', ''),
						'std' => 'Open+Sans',
						'googlefont'=>'heading'
						);

					
$of_options[] = array(
						'id' => 'md_css_googlefont',
						'type' => 'text',
						'name' => __('Body Font', ''),
						'desc' => __('You can select body font via dropdown menu. <strong>500+</strong> google fonts are ready to use', ''),
						'std' => 'Open+Sans',
						'googlefont'=>'text'
						);

										
$of_options[] = array(
						'id' => 'md_css_htmlfont_enable',
						'type' => 'checkbox',
						'name' => __('Use html fonts', ''),
						'desc' => __('If you prefer to use HTML fonts instead of google fonts, enable this option and put your font styles into the text area below :', ''),
						'std' => '0'
						);	

$of_options[] = array(
						'id' => 'md_css_htmlfont',
						'type' => 'text',
						'name' => __('', ''),
						'desc' => __('Font styles. <br>E.g : "Helvetica Neue",Helvetica, Arial', ''),
						'std' => ''
						);	
											
$of_options[] = array( "name" => "Body Font Size",
					"desc" => "",
					"id" => "md_body_fontsize",
					"std" => array('size' => '12px'),
					"type" => "typography");  

										
			
			
			
			


$of_options[] = array( "name" => "SEO",
					"type" => "heading",
					'icon'=>'bar-chart');
															
$of_options[] = 		array(
						'id' => 'md_header_seo_description',
						'type' => 'textarea',
						'name' => __('Site Description', ''),
						'desc' => __('Your website\'s general description.', ''),
						'std' => ''
						);
$of_options[] = 		array(
						'id' => 'md_header_seo_keywords',
						'type' => 'textarea',
						'name' => __('Site Keywords', ''),
						'desc' => __('Your website keywords for SEO optimization. Seperate by comma. E.g. Design, Portfolio, Artist, Design Blog', ''),
						'std' => ''
						);
						
$of_options[] = 		array(
						'id' => 'md_footer_googleanalytics',
						'type' => 'textarea',
						'name' => __('Google Analytics Code', ''),
						'desc' => __('Simply paste your google analytics code in order to get statistics', ''),
						'std' => ''
						);
						
						

						

$of_options[] = array( "name" => "Footer Settings",
					"type" => "heading",
					"icon"=>'file-alt');
	

$of_options[] = 		array(
						'id' => 'md_footer_text',
						'type' => 'text',
						'name' => __('Footer Text', ''),
						'desc' => __('', ''),
						'std' => ''
						);


$of_options[] =			array(
						'id' => 'md_footer_widgets_disabled',
						'type' => 'checkbox',
						'name' => __('Disable Footer Widgets', ''), 
						'desc' => __('', ''),
						'std' => '0'// 1 = on | 0 = off
						);
						

$of_options[] =			array(
						'id' => 'md_footer_widgets_columns',
						'name' => __('Footer Widgets Columns', ''), 
						'desc' => __('How many columns for footer widgets', ''),
						"type" => "select",
						'std' => '4',
						"options" => array(1,2,3,4));  	
														
					
				
$of_options[] = array( "name" => "Social Icons",
					   "type" => "heading",
					   "icon"=>'twitter'
					 );



$of_options[] =  array( "name" =>  "Icon Color",
					"desc" => "",
					"id" => "md_css_socialiconcolors",
					"std" => "#fff",
					"type" => "color"); 
					
										
$of_options[] = 		array(
						'id' => 'md_social_icons',
						'type' => 'socialicons',
						'name' => __('Social Icons (Footer)', ''),
						'desc' => __('', ''),
						'std' => ''
						);	



$of_options[] = array( "name" => "Advanced",
					"type" => "heading",
					'icon'=>'wrench');
											
				
$of_options[] =			array(
						'id' => 'md_retina_support',
						'type' => 'checkbox',
						'name' => __('Disable Retina Support', ''), 
						'desc' => __('This option allows you to deactivate retina display support. By default, this theme requires minimum 470px width images in order to create thumbnails. However, since retina support requires double sized images, recommended thumbnail width has become 940px in order to get corresponding thumbnails created.', ''),
						'std' => '0'// 1 = on | 0 = off
						);


$of_options[] =			array(
						'id' => 'md_master_ajax_disable',
						'type' => 'checkbox',
						'name' => __('Disable Ajax Navigation', ''), 
						'desc' => __('By default, this theme is using ajax navigation for Works, which allows to load content without refreshing the page. All ajax queries are improved for the best performance and optimized for the search engines. However, if you wish to disable ajax queries in order to load pages via traditional HTTP requests, you can activate this option.', ''),
						'std' => '0'// 1 = on | 0 = off
						);

						
													
$of_options[] = 		array(
						'id' => 'md_custom_css',
						'type' => 'textarea',
						'name' => __('Custom CSS', ''),
						'desc' => __('This field allows you to add your custom css styles.', ''),
						'std' => ''
						);
														


$of_options[] = array( "name" => "",
                    "id" => "md_moveposttype_info",
                    "std" => "<strong>Moving Custom Posts</strong><br>
					PLEASE USE THIS OPTION CAREFULLY, THIS ACTION CANNOT BE UNDONE<br>
					This option allows you to move your specific custom post type posts into another one. Also old post type categories will be assigned to the new post type.<br><br>
					For example, you have 2 different post types : works and projects. To move the posts you've created for 'works' into 'projects', pick corresponding post names and run the script.
					<br><br>
					PLEASE NOTE THAT ; the categories which belong to old post type will be MOVED to the new post type along with posts.
					",
                    "type" => "info",
					"desc" => '',
					);
					
										
$of_options[] = 		array(
						'id' => 'md_moveposttype',
						'type' => 'moveposttype',
						'name' => __('Move Custom Post Types', ''),
						'desc' => __('', ''),
						'std' => '0'
						);	
				
				
															

// Backup Options
$of_options[] = array( "name" => "Transfer",
					"type" => "heading",
					"icon"=>'exchange'
					);
					
$of_options[] = array( "name" => "Backup and Restore Options",
                    "id" => "of_backup",
                    "std" => "",
                    "type" => "backup",
					"desc" => 'You can use the two buttons below to backup your current options, and then restore it back at a later time. This is useful if you want to experiment on the options but would like to keep the old settings in case you need it back.',
					);
					
$of_options[] = array( "name" => "Transfer Theme Options Data",
                    "id" => "of_transfer",
                    "std" => "",
                    "type" => "transfer",
					"desc" => 'You can tranfer the saved options data between different installs by copying the text inside the text box. To import data from another install, replace the data in the text box with the one from another install and click "Import Options".
						',
					);
					
	
$of_options[] = array( "name" => "",
                    "id" => "md_migrate_info",
                    "std" => "<strong>Update Your Domain Name for Works Images</strong><br>
					DO NOT USE THIS OPTION UNLESS YOUR DOMAIN NAME IS CHANGED<br>
					This option must be used when your Wordpress content has been moved/imported into another Wordpress (remote server/local server etc.). It allows you to update the current URLs of the \"Works\" post type images. This is a required step since Works images are using absolute URL paths.
					<br><br>
					In order to complete this step, enter your previous website URL and new website URL below, then click to Replace URLs button.<br><br>
					Before proceed, it's strongly recommended to backup your Database.
					",
                    "type" => "info",
					"desc" => '',
					);
					
										
$of_options[] = 		array(
						'id' => 'md_migrate_local',
						'type' => 'migrate',
						'name' => __('Replace URLs', ''),
						'desc' => __('', ''),
						'std' => '0'
						);	
				
																
	}
}
?>
