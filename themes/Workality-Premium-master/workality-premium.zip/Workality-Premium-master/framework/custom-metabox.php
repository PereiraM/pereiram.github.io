<?php

/************************************************************
/* Custom fields for portfolio
/************************************************************/

/// CREATE METABOXES

	
	/// GET CUSTOM TYPES FIRST
	$cc_customtypes = of_get_option('md_custom_posts');
	
	if(is_array($cc_customtypes)) {
		foreach($cc_customtypes as $k => $v) {
			$cc_types[$k] = $v['title']; 
		}
	}else{
		$cc_types[1] = "works";
	}
	
			
	add_action( 'admin_init', 'add_work_fields' );
	add_action( 'save_post', 'save_work_custom_values');
	
	
if ( ! function_exists( 'add_work_fields' ) ) {
	function add_work_fields() {
		
		global $cc_types;
		
		foreach($cc_types as $foo) {
			add_meta_box( 'works-link-fields', __( "External URL", 'dronetv' ), 'works_link_fields', $foo, 'normal', 'high' );
			add_meta_box( 'works-images-fields', __( "Composition", 'dronetv' ), 'works_images_fields', $foo, 'normal', 'core' );
			add_meta_box( 'works-additional-fields', __( "Additional Info &amp; Preferences", 'dronetv' ), 'works_additional_fields', $foo, 'normal', 'core' );
			add_meta_box( 'works-color-fields', __( "Color Settings", 'dronetv' ), 'works_color_fields', $foo, 'normal', 'core' );
			add_meta_box( 'works-gallery-fields', __( "Gallery Settings", 'dronetv' ), 'works_gallery_fields', $foo, 'normal', 'core' );
		}
		
		add_meta_box( 'page-type', __( "Select Custom Post Type", 'dronetv' ), 'page_custom_type', 'page', 'side', 'default' );
		
		
	}
}




if ( ! function_exists( 'works_link_fields' ) ) {
	function works_link_fields() { 
		$args = array(
						array(
							'type'=>'info',
							'desc'=>'This field allows you to bind this project to an external link. If activated, visitors will be redirected to the following URL instead of single project page.'
						),
						array(
							'type'=>'select',
							'title'=>'Activate',
							'name'=>'work-direct-link-activate',
							'desc'=>'',
							'options'=>array(0=>'Deactivated', 1=>'Activated')
						),
						array(
							'type'=>'tfield',
							'title'=>'URL',
							'name'=>'work-direct-link',
							'desc'=>''
						)
				);
		return md_create_fields($args);
	}
}



/// PAGE
if ( ! function_exists( 'page_custom_type' ) ) {
	function page_custom_type() { 
		
		global $cc_types;
		
		$args = array(
						array(
							'type'=>'select',
							'title'=>'Select',
							'name'=>'page-custom-type',
							'desc'=>'',
							'options'=>$cc_types
						)
				);
		return md_create_fields($args);
	}
}





/////// WORKS

if ( ! function_exists( 'md_create_fields' ) ) {		
	function md_create_fields($args) {
		global $post;
		
		$valtype='';
		$valtitle='';
		$valdesc='';
		$valname='';
		$valopt='';
		
		foreach($args as $foo) {
			
			if(isset($foo['type'])) $valtype=$foo['type'];
			if(isset($foo['title'])) $valtitle=$foo['title'];
			if(isset($foo['desc'])) $valdesc=$foo['desc'];
			if(isset($foo['name'])) $valname=$foo['name'];
			if(isset($foo['options'])) $valopt=$foo['options'];
			
			$inp = get_post_meta( $post->ID, $valname, true );
			
			$argsm = array($valtype,$valtitle,$valdesc,$valname,$inp,$valopt);
			
			if(isset($foo['custom'])) array_push($argsm,$foo['custom']);
			
			echo md_cc_field($argsm);
		}
	}
}



if ( ! function_exists( 'works_additional_fields' ) ) {
	function works_additional_fields() { 
		$args = array(
						array(
							'type'=>'info',
							'desc'=>''
						),
						array(
							'type'=>'tfield',
							'title'=>'Client Name',
							'name'=>'work-client',
							'desc'=>'',
							'custom'=>1
						),
						array(
							'type'=>'tfield',
							'title'=>'Project URL',
							'name'=>'work-url',
							'desc'=>'',
							'custom'=>1
						),
						array(
							'type'=>'tfield',
							'title'=>'Project Completion Date',
							'name'=>'work-date',
							'desc'=>'',
							'custom'=>1
						),
						array(
							'type'=>'select',
							'title'=>'Project Description Positioning',
							'name'=>'work-desc-position',
							'desc'=>'',
							'options'=>array('top'=>'Top of the Project', 'bottom'=>'Bottom of the project')
						)
				);
		return md_create_fields($args);
	}
}




if ( ! function_exists( 'works_gallery_fields' ) ) {
	function works_gallery_fields() { 
		$args = array(
						array(
							'type'=>'info',
							'desc'=>'Following settings will be applied if "Gallery" is selected as your Composition Type. For advanced gallery settings, navigate Workality > Gallery section.'
						),
						array(
							'type'=>'select',
							'title'=>'Transparent Canvas',
							'name'=>'work-gallery-canvas-transparent',
							'desc'=>'',
							'options'=>array(0=>'Deactivated', 1=>'Activated')
						),
						array(
							'type'=>'color',
							'title'=>'Gallery BG Color',
							'name'=>'work-gallery-bg',
							'desc'=>''
						)
				);
		return md_create_fields($args);
	}
}




if ( ! function_exists( 'works_color_fields' ) ) {	
	function works_color_fields() { 
		$args = array(	
						array(
							'type'=>'select',
							'title'=>'Transparent Canvas',
							'name'=>'work-color-canvas-transparent',
							'desc'=>'',
							'options'=>array(0=>'Deactivated', 1=>'Activated')
						),
						array(
							'type'=>'color',
							'title'=>'Canvas',
							'name'=>'work-color-canvas',
							'desc'=>''
						),
						array(
							'type'=>'color',
							'title'=>'Title',
							'name'=>'work-color-title',
							'desc'=>''
						),
						array(
							'type'=>'color',
							'title'=>'Text',
							'name'=>'work-color-text',
							'desc'=>''
						),
						array(
							'type'=>'color',
							'title'=>'Links',
							'name'=>'work-color-links',
							'desc'=>''
						),
						array(
							'type'=>'color',
							'title'=>'Borders',
							'name'=>'work-color-borders',
							'desc'=>''
						)
				);
		return md_create_fields($args);
	}
}




if ( ! function_exists( 'works_images_fields' ) ) {
	function works_images_fields() { 
		$args = array(	
						array(
							'type'=>'info-array',
							'desc'=>__('<span class="imghelp" style="font-size:11px;line-height:17px; float:left; width:100%; display:none"><strong>Images :</strong> Click to "Add New Image" button to upload image(s) or select an image from your WP image library. Adding multiple images is allowed and images/videos can be re-ordered once they\'re added to your project. By default, images are displayed with <strong>880px</strong> maximum width in project canvas. <br>Smaller images than <strong>880px</strong> will be displayed in their original size as centered. <br>
<strong style="color:#fd0d4d">Important Note :</strong> If "Remove side margins on single project pages" option is enabled, you\'re be able to use 940px image width instead of default 880px.						
							<br><br><strong>Videos :</strong> Click to "Add New Video" button to add video embed code which is generated by video service website such as youtube, vimeo, dailymotion. Embed video size will be ignored and your videos will be automatically stretched to your project canvas with preserved aspect ratio. If you\'re using Gallery mode for your composition, you should add Vimeo or Youtube video URL instead of embed code.  
							<br><br><strong>Text :</strong> You can add text areas into your canvas. Rich text editor allows you to add shortcodes and style your text.
							<br><br><strong>Composition Type :</strong>  By default your images will be placed vertically with following order. Gallery type will create a gallery with following image and video content. If you selected "Gallery" type, "Text" items will be ignored.	
							<br><br><strong>NOTE :</strong> You MUST click update button to save all changes once you\'ve added the project assets
												
							</span>','dronetv')
						),array(
							'type'=>'imagearr',
							'title'=>'',
							'name'=> 'work-media',
							'desc'=>''
						)
				);
		return md_create_fields($args);
	}

}
	


if ( ! function_exists( 'works_video_fields' ) ) {	
	function works_video_fields() { 
		$args = array(	
						array(
							'type'=>'info',
							'desc'=> __('Add video embed code which is generated by video service website such as youtube, vimeo etc. Any video embed code will be accepted. <br>Also you don\'t need to worry about dimensions of your embeded code unless it\'s from Vimeo or Youtube. It will be stretched horizontally in your page with preserved aspect ratio.','dronetv')
						),array(
							'type'=>'tarea',
							'title'=>'Video Embed',
							'name'=>'work-video',
							'desc'=>''
						)
				);
		return md_create_fields($args);
	}
}


	
	/////// BOX CREATOR

if ( ! function_exists( 'wrap' ) ) {	
	function wrap($pick, $args=array()) {
		global $post;
		
		$spid = '';
		if($pick==2) {
			return $sh = '</td></table>';
		}else{
			if($args[0]=='imagearr') { 
				$spid = 'id="md-sortable-media"';
			}
			
			if($args[0]=='imagearr') { 
			
			return $sh = '<input type="hidden" name="work_token" value="'.wp_create_nonce( basename(__FILE__) ).'" /><table class="custom-fields form-table"><tr><td '.$spid.' style="display:block;width:auto">';
			
			}else{
				
				if(isset($args[6]) && $args[6]==1) { 
				
				$val= get_post_meta( $post->ID , $args[3].'-title', true );
				
			return $sh = '<table class="custom-fields form-table"><tr><th><input type="hidden" name="work_token" value="'.wp_create_nonce( basename(__FILE__) ).'" />
			<label for=""><input type="text" name="'.$args[3].'-title" value="'.$val.'" style="width:140px;font-size:11px" placeholder="'.$args[1].'"></label><br /><p>'.__( $args[2], 'dronetv' ).'</p></th><td '.$spid.'>';
				
				}else{
					
			return $sh = '<table class="custom-fields form-table"><tr><th><input type="hidden" name="work_token" value="'.wp_create_nonce( basename(__FILE__) ).'" />
			<label for="">'.$args[1].'</label><br /><p>'.__( $args[2], 'dronetv' ).'</p></th><td '.$spid.'>';	
				
				}
			}
			
		}
	}
}


if ( ! function_exists( 'createToken' ) ) {
	function createToken() { 
		//echo '<input type="hidden" name="work_token" value="'.wp_create_nonce( basename(__FILE__) ).'" />';
	}
}



if ( ! function_exists( 'md_cc_field' ) ) {	
	function md_cc_field ($args=array()) {
		
		global $post;
		
		$fieldid = 1;
		$idkey = "dpost-";
	
		$idkey = $idkey.$fieldid; 
		if($args[0]=='info' || $args[0]=='info-array') {
			if($args[0]=='info-array') {
			
			$inps = get_post_meta( $post->ID, 'work-comp-type', true );
				
			$res = '<div style="width:97%; padding:30px 15px 0 15px; float:left">
					<a href="javascript:void(0);" class="nhp-opts-upload button-secondary" rel-id="new">Add New Image</a>
					<a href="javascript:void(0);" class="add-more-videos button-secondary" rel-id="new">Add Video</a>
					<a href="javascript:void(0);" class="add-more-text button-secondary" rel-id="new">Add Text</a>
					<a href="#" onclick="jQuery(\'.imghelp\').slideToggle();return false;" style="margin-left:15px">Help</a>
					
					<span style="float:right;text-align:right">
						Composition Type : 
						<select name="work-comp-type" style="width:100px">
							<option value="1" '.selected($inps, 1, false).'>Default</option>
							<option value="2" '.selected($inps, 2, false).'>Gallery</option>
						</select>
					</span>
					<br class="clear"><br class="clear">
					'.$args[2].'
					</div>';	
			}else{
			$res = '<table class="custom-fields form-table"><tr><td colspan="2"><h4>'.$args[2].'</h4></td></tr></table>';
			}
		}else{
		$res = wrap(1,$args);
		$res .= fieldType($args);
		$res .= wrap(2);
		}
		$fieldid ++;
		
		return $res;
	}
}



if ( ! function_exists( 'fieldType' ) ) {
	function fieldType($args) {
		
		global $post;
		
		$type = $args[0];
		$key = $args[3];
		$val = $args[4];
		$output = '';
		
		if($type=='tarea') {
			return $output= '<textarea id="'.$key.'" cols="60" rows="3" name="'.$key.'">'.$val.'</textarea>';
		}
		if($type=='color') {
			$output .= '<div id="' . $key . '_picker" class="colorSelector"><div style="background-color: '.$val.'"></div></div>';
		    $output .= '<input class="of-color" name="'.$key.'" id="'. $key .'" type="text" style="width: 80px;padding: 5px;margin-top: 0px;margin-left: 5px;" value="'. $val .'" />';
			return  $output;
		}
		if($type=='select') {
			
			$output .= '<select id="'.$key.'" name="'.$key.'">';
				foreach($args[5] as $k=>$v) {
					if($val==$k) { $sel1 = 'selected'; }else{ $sel1= '';}
					$output .= '<option value="'.$k.'" '.$sel1.'>'.$v.'</option>';
				}
			$output .= '</select>';
			return $output;
			
		}
		if($type=='tfield') {
			return $output= '<input id="'.$key.'" class="upload" type="text" name="'.$key.'" value="'.$val.'" />';
		}
		if($type=='checkbox') {
			return $output= '<input id="'.$key.'" class="upload" type="checkbox" name="'.$key.'" value="1" '.checked($val,1,false).'" />';
		}
		if($type=='tfielddate') {
			return $output= '<input id="'.$key.'" class="upload get-datepicker" type="text" name="'.$key.'" value="'.$val.'" />';
		}
		
		if($type=='imagearr') {
			$s1=0;
			$s2=0;
			$s3=0;
			$output = "";
			$media = unserialize($val);
			$mediacaption = unserialize(get_post_meta( $post->ID, 'work-media-caption', true ));
			$medialink = unserialize(get_post_meta( $post->ID, 'work-media-link', true ));
			$medialinktarget = unserialize(get_post_meta( $post->ID, 'work-media-link-target', true ));
			$mediavideo = unserialize(get_post_meta( $post->ID, 'work-media-video', true ));
			$mediatext = unserialize(get_post_meta( $post->ID, 'work-media-text', true ));
			$mediapalign = unserialize(get_post_meta( $post->ID, 'work-media-photoalignment', true ));
			
			if(is_array($media)) {
				foreach($media as $v) {
					if($v=='textarea') {
						
					$output .= '<div class="imgarr"><span class="imgside">';
					$output .= '<input type="hidden" name="work-media[]" value="textarea" />';
					
					$output .= '<textarea id="tinymceids-'.$s3.'" cols="60" style="width:600px;height:300px;" class="mceEditor" name="work-media-text[]">'.stripslashes($mediatext[$s3]).'</textarea><br class="clear">';
					$output .= '<a href="javascript:void(0);" class="admin-upload-remove button-secondary" rel-id="work-media-'.$s3.'">'.__('Remove', 'dronetv').'</a>';
					$output .= '</span><br class="clear"></div>';
					$s3++;
					
					
					}elseif($v=='videoembed') {
						
					$output .= '<div class="imgarr"><span class="imgside">';
					$output .= '<input type="hidden" name="work-media[]" value="videoembed" />';
					$output .= '<img width="120" class="screenshot" src="'.ADMIN_IMG_DIRECTORY.'youtube.png" /></span><span>';
					$output .= '<strong>Video Embed Code</strong><br class="clear" ><small>IMPORTANT : If you\'re using Gallery as your Composition Type, Vimeo or Youtube URL MUST be used instead of embed code. <br>E.g. http://www.youtube.com/watch?v=GCZrz8siv4Q</small><br class="clear" >';
					$output .= '<textarea id="work-media-video-'.$s1.'" cols="60" rows="3" class="video-caption" name="work-media-video[]">'.stripslashes($mediavideo[$s1]).'</textarea><br class="clear">';
					$output .= '<a href="javascript:void(0);" class="admin-upload-remove button-secondary" rel-id="work-media-'.$s1.'">'.__('Remove', 'dronetv').'</a>';
					$output .= '</span><br class="clear"></div>';
					$s1++;
					
					}else{
					
					$output .= '<div class="imgarr"><span class="imgside">';
					$output .= '<input type="hidden" id="work-media-'.$s2.'" name="work-media[]" value="'.$v.'" />';
					$output .= '<div class="imgwindow"><img width="120" class="screenshot" id="sc-'.$s2.'" src="'.$v.'" /></div>';
					$output .= '</span><span>';
					$output .= '<strong>Image Caption</strong><br class="clear" >';
					$output .= '<textarea id="work-media-caption-'.$s2.'" cols="60" style="height:50px;" class="work-caption" name="work-media-caption[]">'.stripslashes($mediacaption[$s2]).'</textarea>';
					$output .= '<br class="clear"><small><strong>URL</strong> (Optional. If present, image will be wrapped with this URL)</small><br class="clear" >';
					$output .= '<input type="text" style="width:200px;" placeholder="E.g. http://www.northeme.com" id="work-media-link-'.$s2.'" name="work-media-link[]" value="'.stripslashes($medialink[$s2]).'" />';
					
					$output .= '<select id="work-media-link-target-'.$s2.'" name="work-media-link-target[]" class="urlselector">';
					
					$output .= '<option value="_blank" '.selected($medialinktarget[$s2], '_blank', false).'>Open in New Window</option><option value="_self" '.selected($medialinktarget[$s2], '_self', false).'>Open in Same Window</option>';
					
					$output .= '</select>';
					
					$msel = @$mediapalign[$s2];
					
					$output .= '<br class="clear">
								<label class="radio bloghide"><input type="radio" name="work-media-photoalignment['.$s2.']" '.checked($msel, 'landscape', false).' value="landscape"> Landscape</label>
								<label class="radio bloghide"><input type="radio" name="work-media-photoalignment['.$s2.']" '.checked($msel, 'portrait', false).' value="portrait"> Portrait</label>'; 
								
								
					$output .= '<a href="javascript:void(0);" class="admin-upload-remove button-secondary" rel-id="work-media-'.$s2.'">'.__('Remove', 'dronetv').'</a><br class="clear">';
					$output .= '</span><br class="clear"></div>';
					$s2++;
					
					}
				}
			}
			return $output;
		}
		
	}
}





if ( ! function_exists( 'save_work_custom_values' ) ) {
	function save_work_custom_values( $post_id ) {
		  
		  global $post;
		  // verify if this is an auto save routine. 
		  // If it is our form has not been submitted, so we dont want to do anything
		  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
			  return;
	
		  // verify this came from the our screen and with proper authorization,
		  // because save_post can be triggered at other times
		  if(isset($_POST['work_token'])) {
			  if ( !wp_verify_nonce( $_POST['work_token'], basename( __FILE__ ) ) )
				return;
		  }else{
				return;  
		  }
		  
		  // Check permissions
		  if ( 'page' == $_POST['post_type'] ) 
		  {
			if ( !current_user_can( 'edit_page', $post_id ) )
				return;
		  }
		  else
		  {
			if ( !current_user_can( 'edit_post', $post_id ) )
				return;
		  }
	
	
			//// Handle custom values
		if( $post->post_type == "page" && $_POST['page_template']=="template-works.php") {
			
			global $custompostvals;
			
			update_post_meta($post->ID, 'page-custom-type', $_POST['page-custom-type']);
			$cc_customtypes = of_get_option('md_custom_posts',1);
			
			
			if(is_array($cc_customtypes)) {
				$osettings = get_option(OPTIONS);
			}else{
				$osettings['md_custom_posts'][1]=$custompostvals;
			}
			
			$osettings['md_custom_posts'][$_POST['page-custom-type']]['home_url'] = $post->ID;
			
			update_option(OPTIONS, $osettings);
			
		}else{
			
				foreach($_POST as $inp => $val) {
					if(strpos($inp,'work-')!==false) {
					
					$itworks=1;
						
					if($inp=='work-media' || $inp=='work-media-caption' || $inp=='work-media-video' || $inp=='work-media-text' || $inp=='work-media-link' || $inp=='work-media-link-target' || $inp=='work-media-photoalignment' || strpos($inp,'work-customs')!==false) {
						@$varm = addslashes( serialize( $val));
					}else{
						@$varm = stripslashes(htmlspecialchars( $val));
					}
				
					update_post_meta($post->ID, $inp, $varm);
					}
				}	
				
				if(isset($itworks)) {	
					if(!isset($_POST['work-media'])) {
						update_post_meta($post->ID, 'work-media', '');	
						update_post_meta($post->ID, 'work-media-caption', '');	
						update_post_meta($post->ID, 'work-media-video', '');	
					}
				}
				
		}	
		
	}
}
?>