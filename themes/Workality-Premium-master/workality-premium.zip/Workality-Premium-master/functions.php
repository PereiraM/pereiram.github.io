<?php
/************************************************************
/* OPTIONS FRAMEWORK
/************************************************************/

define('OPTIONS', 'drone_options');
define('BACKUPS','drone_backups' );

require_once ('framework/options/index.php');

// PATHS
define('THEME_FILEPATH', get_template_directory());
define('THEME_DIRECTORY', get_template_directory_uri());
define('ADMIN_IMG_DIRECTORY', get_template_directory_uri().'/framework/options/assets/images/');


/************************************************************
/* CUSTOM POST DEFAULT VALUES
/************************************************************/

		$custompostvals['title'] = "works"; // post name / slug
		$custompostvals['singular'] = "Project"; // single name
		$custompostvals['plural'] = "Works"; // name
		$custompostvals['slug'] = "works"; // slug
		
		$custompostvals['categoryname'] = "Creative Fields"; // category name
		$custompostvals['categorytitle'] = "Add New Field"; // 
		$custompostvals['categorysingletitle'] = "Field"; // 
		$custompostvals['categoryslug'] = "field"; // 
		$custompostvals['color'] = ''; // 	
		$custompostvals['withbg'] = 0; // 	
		$custompostvals['dropdown'] = 0; // 	
		$custompostvals['dropdowntitle'] = '';
		$custompostvals['hideheader'] = 0;
		$custompostvals['thumbnail'] = 'medium';
		$custompostvals['removesidemargin'] = 0; // 
		$custompostvals['pagination'] = 0; // 
		$custompostvals['showcategory'] = 0; // 
		$custompostvals['showexcerpt'] = 1;
		$custompostvals['showtitle'] = 1;
		$custompostvals['showdate'] = 0; // 
		$custompostvals['projectinfo'] = 0; // 
		$custompostvals['orderby'] = 0; // 
		$custompostvals['thumbhover']=1; //
		$custompostvals['thumbhovercolor']='#ffffff'; //


if ( !function_exists( 'of_get_custom' ) ) {
	function of_get_custom($name, $default = false) {
			/// for custom
			$optionsframework_settings = get_option('drone_custom_types');
			
			if(!isset($optionsframework_settings['md_custom_posts']) && $name=='md_custom_posts') {
				return $option_name = $custompostvals;
			}
			
			if (isset($optionsframework_settings[$name])) {
				return $option_name = $optionsframework_settings[$name];
			}else{
				return false;
			}
	}
}

if ( !function_exists( 'of_get_option' ) ) {
	function of_get_option($name, $default = false) {
			/// for custom
			global $custompostvals;
			
			$optionsframework_settings = get_option('drone_options');
		
			if(!is_array($optionsframework_settings['md_custom_posts']) && $name=='md_custom_posts' && !$default) {
				$varm[1] = $custompostvals;
				return $varm;
			}
			
			$option_name = @$optionsframework_settings[$name];
			if (isset($option_name)) {
				return $option_name;
			}else{
				return false;
			}
	}
}






/************************************************************
/* URL FILTER
/************************************************************/

	function seoUrl($url) {
		// Make sure string is in UTF-8 and strip invalid UTF-8 characters
        return sanitize_title($url);
	}

	

/************************************************************
/* SITE COLOR SETTINGS
/************************************************************/
if ( ! function_exists( 'siteIcons' ) ) {
	function siteIcons() {
			
			if(isset($_SESSION['md_props']['md_css_presets'])) {
			$presets = $_SESSION['md_props']['md_css_presets'];
			}else{
			$presets = of_get_option('md_css_presets');
			}
			
			if($presets=='light') {
			
				// DEFAULT LIGHT SETTINGS
				$md_whiteicons = false; 
				
			}elseif($presets=='dark') {
			
				// DEFAULT DARK SETTINGS
				$md_whiteicons = true; 
			
			}elseif($presets=='custom') {
	
				// GET COLOR OPTIONS
				if(of_get_option('md_css_whiteicons')) { $md_whiteicons = of_get_option('md_css_whiteicons');}
				
			}else{
				// DEFAULT GRAY SETTINGS
				$md_whiteicons = false;
			}
			
			return $md_whiteicons;
	}
}


if ( ! function_exists( 'siteColors' ) ) {
	function siteColors() {
			
			// DEFAULT VARS
			$md_googlefont = "Open Sans";
			$md_bgpattern ='';
			$md_fontcolor='';
			$md_heading='';
			$md_linkcolor='';
			$md_activelinkcolor='';
			$md_textshadow='';
			$md_bordercolor='';
			$md_css_borderstyle='';
			$md_activemenucolor='';
			$md_activemenucolor_selected='';
			$md_activemenubg='';
			$md_activemenubg_selected='';
			$md_formelement='';
			$md_googlefont_header='';
			$md_whiteicons='';
			$md_css_mainbgcolor='';
			$md_body_fontsize='';
			
			
			if(isset($_SESSION['md_props']['md_css_presets'])) {
			$presets = $_SESSION['md_props']['md_css_presets'];
			}else{
			$presets = of_get_option('md_css_presets');
			}
			
			
			
			if($presets=='light') {
			
				// DEFAULT LIGHT SETTINGS
				//$md_bgpattern = '_Plain_White.png';
				$md_fontcolor = '#666666';
				$md_heading = '#000000';
				$md_linkcolor = '#000000'; 
				$md_activelinkcolor = '#d10000';
				$md_textshadow = '#ffffff'; 
				$md_bordercolor = '#f0f0f0';
				$md_activemenucolor = '#666';
				$md_activemenucolor_selected = '#e6e6e6';
				$md_activemenubg = '#f0f0f0';
				$md_activemenubg_selected = '#3d3d3d';
				$md_formelement = '#f2f2f2'; 
				$md_whiteicons = false; 
				
				
			}elseif($presets=='dark') {
			
				// DEFAULT DARK SETTINGS
				//$md_bgpattern = 'dark_navy_blue.png';
				$md_fontcolor = '#808080';
				$md_heading = '#a6a6a6';
				$md_linkcolor = '#a6a6a6'; 
				$md_activelinkcolor = '#ffffff';
				$md_textshadow = '#000000'; 
				$md_bordercolor = '#333';
				$md_activemenucolor = '#f0f0f0';
				$md_activemenucolor_selected = '#fff';
				$md_activemenubg = '#444';
				$md_activemenubg_selected = '#777';
				$md_formelement = '#555'; 
				$md_whiteicons = true; 
			
			}elseif($presets=='custom') {
	
				// GET COLOR OPTIONS
				if(of_get_option('md_css_fontcolor')) { $md_fontcolor = of_get_option('md_css_fontcolor');}
				if(of_get_option('md_css_heading')) { $md_heading = of_get_option('md_css_heading');}
				if(of_get_option('md_css_linkcolor')) { $md_linkcolor = of_get_option('md_css_linkcolor');}
				if(of_get_option('md_css_linkcolorhover')) { $md_activelinkcolor = of_get_option('md_css_linkcolorhover');}
				if(of_get_option('md_css_textshadow')) { $md_textshadow = of_get_option('md_css_textshadow');}
				if(of_get_option('md_css_bordercolor')) { $md_bordercolor = of_get_option('md_css_bordercolor');}
				if(of_get_option('md_css_activemenucolor')) { $md_activemenucolor = of_get_option('md_css_activemenucolor');}
				if(of_get_option('md_css_activemenucolor_selected')) { $md_activemenucolor_selected = of_get_option('md_css_activemenucolor_selected');}
				if(of_get_option('md_css_activemenubg')) { $md_activemenubg = of_get_option('md_css_activemenubg');}
				if(of_get_option('md_css_activemenubg_selected')) { $md_activemenubg_selected = of_get_option('md_css_activemenubg_selected');}
				if(of_get_option('md_css_formelement')) { $md_formelement = of_get_option('md_css_formelement');}
				if(of_get_option('md_css_whiteicons')) { $md_whiteicons = of_get_option('md_css_whiteicons');}
				
			}else{
			
				// DEFAULT GRAY SETTINGS
				//$md_bgpattern = 'bedge_grunge.jpg';
				$md_fontcolor = '#666';
				$md_heading = '#000';
				$md_linkcolor = '#333'; 
				$md_activelinkcolor = '#000';
				$md_textshadow = '#f0f0f0'; 
				$md_bordercolor = '#bbb';
				$md_activemenucolor = '#666';
				$md_activemenucolor_selected = '#fff';
				$md_activemenubg = '#f9f9f9';
				$md_activemenubg_selected = '#aaa';
				$md_formelement = '#f9f9f9'; 
				$md_whiteicons = false; 
				
			}
			
			// BG PATTERN
			if(of_get_option('md_css_bgpattern')) { $md_bgpattern = of_get_option('md_css_bgpattern');}
			if(of_get_option('md_css_mainbgcolor')) { $md_css_mainbgcolor = of_get_option('md_css_mainbgcolor'); }
			if(of_get_option('md_css_borderstyle')) { $md_css_borderstyle = of_get_option('md_css_borderstyle');}else{ $md_css_borderstyle = 'solid'; }
			if(of_get_option('md_body_fontsize')) { $md_body_fontsize = of_get_option('md_body_fontsize');}
			if(of_get_option('md_css_googlefont')) { $md_googlefont = of_get_option('md_css_googlefont');}
			if(of_get_option('md_css_googlefont_header')) { $md_googlefont_header = of_get_option('md_css_googlefont_header');}
			
			return array(
			'bgpattern'=>$md_bgpattern,
			'fontcolor'=>$md_fontcolor,
			'headingcolor'=>$md_heading,
			'linkcolor'=>$md_linkcolor,
			'linkcoloractive'=>$md_activelinkcolor,
			'textshadow'=>$md_textshadow,
			'bordercolor'=>$md_bordercolor,
			'borderstyle'=>$md_css_borderstyle,
			'menufont'=>$md_activemenucolor,
			'menufontactive'=>$md_activemenucolor_selected,
			'menubg'=>$md_activemenubg,
			'menubgactive'=>$md_activemenubg_selected,
			'formelement'=>$md_formelement,
			'googlefontbody'=>$md_googlefont,
			'googlefontheader'=>$md_googlefont_header,
			'whiteicons'=>$md_whiteicons,
			'bgcolor'=>$md_css_mainbgcolor,
			'bodyfontsize'=>$md_body_fontsize);
		}
}
	
	

/************************************************************
/* Theme Settings
/************************************************************/
add_theme_support( 'menus' ); // add custom menus support
add_theme_support('automatic-feed-links');
add_theme_support('post-thumbnails');
add_filter('widget_text', 'do_shortcode');

add_action('init', 'my_custom_init');

add_editor_style();
		
// Excerpt
if ( ! function_exists( 'my_custom_init' ) ) {
	function my_custom_init() {
		add_post_type_support( 'page', 'excerpt' );
		add_post_type_support( 'post', 'excerpt' );
		add_post_type_support( 'works', 'excerpt' );
	}
}
// Remove rel attribute from the category list
if ( ! function_exists( 'remove_category_list_rel' ) ) {
	function remove_category_list_rel($output)
	{
	  $output = str_replace(' rel="category tag"', '', $output);
	  return $output;
	}
}

add_filter('wp_list_categories', 'remove_category_list_rel');
add_filter('the_category', 'remove_category_list_rel');



/// INCLUDE WORKS INTO SEARCH
if ( ! function_exists( 'filter_search' ) ) {
	function filter_search($query) {
		if ($query->is_search) {
		$query->set('post_type', array('post', 'page','works'));
		};
		return $query;
	};
}
	
add_filter('pre_get_posts', 'filter_search');

if ( ! function_exists( 'filter_tag' ) ) {
	function filter_tag($query) {
		if ($query->is_tag) {
		$query->set('post_type', array('post', 'works'));
		};
		return $query;
	};
}
add_filter('pre_get_posts', 'filter_tag');



// Translation files can be added to /languages directory
load_theme_textdomain( 'dronetv', TEMPLATEPATH . '/languages' );

$locale = get_locale();
$locale_file = TEMPLATEPATH."/languages/$locale.php";
if ( is_readable($locale_file) )
	require_once($locale_file);
	



/************************************************************
/* Featured Image Sizes
/************************************************************/
if ( ! isset( $content_width ) ) $content_width = 980;

set_post_thumbnail_size(100, 100, true);

$thumbs_portrait_w = 300;
$thumbs_portrait_h = 420;

$thumbs_large_w = 460;
$thumbs_large_h = 350;

$thumbs_medium_w = 300;
$thumbs_medium_h = 100;

$thumbs_medium_regular_w = 300;
$thumbs_medium_regular_h = 225;

$thumbs_small_w = 220;
$thumbs_small_h = 170;

add_image_size('md_post_thumb_large', $thumbs_large_w, $thumbs_large_h, true);
add_image_size('md_post_thumb_medium', $thumbs_medium_w, $thumbs_medium_h, true);
add_image_size('md_post_thumb_medium_regular', $thumbs_medium_regular_w, $thumbs_medium_regular_h, true);
add_image_size('md_post_thumb_small', $thumbs_small_w, $thumbs_small_h, true);
add_image_size('md_post_thumb_portrait', $thumbs_portrait_w, $thumbs_portrait_h, true);


/************************************************************
/* Create @2x Images for Retina Display
/************************************************************/
if(of_get_option('md_retina_support')!=1) { 
	add_image_size( 'md_post_thumb_large@2x', $thumbs_large_w * 2, $thumbs_large_h * 2, true );
	add_image_size( 'md_post_thumb_medium@2x', $thumbs_medium_w * 2, $thumbs_medium_h * 2, true );
	add_image_size( 'md_post_thumb_medium_regular@2x', $thumbs_medium_w * 2, $thumbs_medium_h * 2, true );
	add_image_size( 'md_post_thumb_small@2x', $thumbs_small_w * 2, $thumbs_small_h * 2, true );
	add_image_size( 'md_post_thumb_portrait@2x', $thumbs_portrait_w * 2, $thumbs_portrait_h * 2, true );
}


// IMAGE QUALITY
function gpp_jpeg_quality_callback($arg) {
	return (int)95; // change 100 to whatever you prefer, but don't go below 60
}

add_filter('jpeg_quality', 'gpp_jpeg_quality_callback');



if ( ! function_exists( 'getThumb' ) ) {	
	function getThumb($th) {
		global $post;
		
		switch($th) {
			case 'mini':
			  $class = 'four columns featured';
			  $thumbsize = 'md_post_thumb_small';
			  $after = 4;
			break;
			case 'small':
			  $class = 'four columns featured';
			  $thumbsize = 'md_post_thumb_small';
			  $after = 4;
			break;
			case 'medium':
			  $class = 'one-third column featured';
			  $thumbsize = 'md_post_thumb_medium';
			  $after = 3;
			break;
			case 'medium-regular':
			  $class = 'one-third column featured';
			  $thumbsize = 'md_post_thumb_medium_regular';
			  $after = 3;
			break;
			case 'large':
			  $class = 'eight columns featured';
			  $thumbsize = 'md_post_thumb_large';
			  $after = 2;
			break;
			case 'portrait':
			  $class = 'one-third column featured';
			  $thumbsize = 'md_post_thumb_portrait';
			  $after = 3;
			break;
		}
		
		if ( isset( $_COOKIE['devicePixelRatio'] ) && $_COOKIE['devicePixelRatio'] > 1.5 && of_get_option('md_retina_support')!=1) $thumbsize = $thumbsize.'@2x';
		
		$img = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), $thumbsize );
		return array($img[0],$class,$thumbsize,$after);
	}
}	
	
if ( ! function_exists( 'getThumbRows' ) ) {	
	function getThumbRows($th) {
		global $post;
		
		switch($th) {
			case 'mini':
			  $after = 4;
			break;
			case 'small':
			  $after = 4;
			break;
			case 'medium':
			  $after = 3;
			break;
			case 'medium-regular':
			  $after = 3;
			break;
			case 'large':
			  $after = 2;
			break;
			case 'portrait':
			  $after = 3;
			break;
		}
		return $after;
	}
}	



/************************************************************
/* Widgets & Shortcodes
/************************************************************/

//// Excerpt Length
add_theme_support('excerpt');

if ( ! function_exists( 'custom_excerpt_length' ) ) {
	function custom_excerpt_length( $length ) {
		return 20;
	}
}
if ( ! function_exists( 'new_excerpt_more' ) ) {
	function new_excerpt_more( $more ) {
		return '...';
	}
}
add_filter('excerpt_more', 'new_excerpt_more');
add_filter('excerpt_length', 'custom_excerpt_length', 999 );

							
/************************************************************
/* Share Funcs
/************************************************************/

if ( ! function_exists( 'showshareingpost' ) ) {
	function showshareingpost($url,$img, $title, $code=false,$top=false) { 
	
		$output = '';
		
		if(of_get_option('md_social_post_facebook')) {
			if(!$code) {
		$output .= '<div class="facebook shr"><iframe src="//www.facebook.com/plugins/like.php?href='.urlencode($url).'&amp;send=false&amp;layout=button_count&amp;width=50&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:21px;" allowTransparency="true"></iframe></div>';
		if($top) $output .= '<br class="clear">';
			}else{
		$output .='';
			}
		}
		
		if(of_get_option('md_social_post_twitter')) {
			if(!$code) {
		$output .= '<div class="twitter shr"><a href="https://twitter.com/share" class="twitter-share-button" data-count="none" data-url="'.$url.'" data-text="'.$title.'">Tweet</a></div>';
			if($top) $output .= '<br class="clear">';
			}else{
		$output .= '<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>'; 
			}
		}
	
		if(of_get_option('md_social_post_googleplus')) {
			if(!$code) {
		$output .= '<div class="googleplus shr"><div class="g-plusone" data-size="medium" data-annotation="none"></div></div>';
			if($top) $output .= '<br class="clear">';
			}else{
		$output .= '<script type="text/javascript">
		(function() {
		var po = document.createElement(\'script\'); po.type = \'text/javascript\'; po.async = true;
		po.src = \'https://apis.google.com/js/plusone.js\';
		var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(po, s);
		})();</script>'; 
			}
		}
		
		if(of_get_option('md_social_post_pinterest')) {
			if(!$code) {
		$output .= '<div class="pinterest shr"><a href="http://pinterest.com/pin/create/button/?url='.urlencode($url).'&amp;media='.urlencode($img).'&amp;description='.urlencode($title).'" class="pin-it-button"><img style="border:none" src="//assets.pinterest.com/images/PinExt.png" title="Pin It" /></a></div>';
			if($top) $output .= '<br class="clear">';
			}else{
		$output .= '<script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script>'; 
			}
		}
		
		if(of_get_option('md_social_post_tumblr')) {
			if(!$code) {
		$output .= '<div class="tumblr shr"><a href="http://www.tumblr.com/share" title="Share on Tumblr" style="display:inline-block; text-indent:-9999px; overflow:hidden; width:61px; height:20px; background:url(\'http://platform.tumblr.com/v1/share_4.png\') top left no-repeat transparent;"></a></div>';
			}else{
		$output .= '<script type="text/javascript" src="http://platform.tumblr.com/v1/share.js"></script>'; 
			}
		}
		
		
		if(of_get_option('md_social_post_vkshare')) {
			if(!$code) { 
			$output .= '<script type="text/javascript" src="http://vk.com/js/api/share.js?11"></script>';
			$output .= "<script type=\"text/javascript\">
						<!--
						document.write(VK.Share.button({
						  url: '".urlencode($url)."',
						  title: '".urlencode($title)."',
						  image: '".urlencode($img)."',
						  noparse: true
						},{type: \"round_nocount\", text: \"Share\"}));
						-->
						</script>"; 	
			}
		}
		
		return $output;
	
	}
}



if ( ! function_exists( 'showSharing' ) ) {
	function showSharing() {
		
		$iconvar = of_get_option('md_social_icons');
		$iconvarcolor = of_get_option('md_css_socialiconcolors');
		
		$s=0;
		if(is_array($iconvar['type'])) {
			foreach($iconvar['type'] as $v) {
				
					echo '<a href="'.$iconvar['link'][$s].'" target="_blank"><i style="color:'.$iconvarcolor.'">'.strtolower($v).'</i></a>';	

				  $s++;
			}
		
		}
	}                 
}


							
/************************************************************
/* WORKS STYLES
/************************************************************/

if ( ! function_exists( 'workStyles' ) ) {
	function workStyles() {
			global $post;
			
			// DEFAULT SETTINGS FOR WORKS
			$md_works_canvas = '#fff'; 
			$md_works_title = '#333'; 
			$md_works_text = '#666'; 
			$md_works_links = '#000'; 
			$md_works_borders = '#f0f0f0'; 
			
			// GET COLOR OPTIONS FOR WORKS
			if(get_post_meta( $post->ID, 'work-color-canvas', true )) { $md_works_canvas = get_post_meta( $post->ID, 'work-color-canvas', true );}
			if(get_post_meta( $post->ID, 'work-color-title', true )) { $md_works_title = get_post_meta( $post->ID, 'work-color-title', true );}
			if(get_post_meta( $post->ID, 'work-color-text', true )) { $md_works_text = get_post_meta( $post->ID, 'work-color-text', true );}
			if(get_post_meta( $post->ID, 'work-color-links', true )) { $md_works_links = get_post_meta( $post->ID, 'work-color-links', true );}
			if(get_post_meta( $post->ID, 'work-color-borders', true )) { $md_works_borders = get_post_meta( $post->ID, 'work-color-borders', true );}
			
			// BORDER STYLE
			if(of_get_option('md_css_borderstyle')) { $md_css_borderstyle = of_get_option('md_css_borderstyle');}else{ $md_css_borderstyle = 'solid'; }
			?>
			 <style type="text/css">
				.postwraps { 
					<?php if(get_post_meta( $post->ID, 'work-color-canvas-transparent', true )==1) { ?>
					background:none!important;
					<?php }else{ ?>
					background-color:<?php echo $md_works_canvas; ?>!important;
					<?php } ?>
					color:<?php echo $md_works_text; ?>!important;
				}
				.postwraps .sharingbottom.tops {
					background-color:<?php echo $md_works_canvas; ?>!important;
				}
				.postwraps p a, .postwraps .caption a, .postwraps .pinfo a, .postwraps .comment-list a { 
					color:<?php echo $md_works_links; ?>;
				}
				.postwraps h2 a, .postwraps h2#comments, .postwraps h3#reply-title { 
					color:<?php echo $md_works_title; ?>!important;
				}
				.postwraps .border-color-works { 
					border-color:<?php echo $md_works_borders; ?>!important;
					border-style:<?php echo $md_css_borderstyle;?>!important;
				}
				.postwraps div.contenttext h1,
				.postwraps div.contenttext h2,
				.postwraps div.contenttext h3,
				.postwraps div.contenttext h4,
				.postwraps div.contenttext h5,
				.postwraps div.contenttext h6 {
					text-shadow:none!important;
					color:<?php echo $md_works_text; ?>!important;
				}
			</style>								
			<?php
	}
}


							
/************************************************************
/* PROJECT NAVIGATION
/************************************************************/

if ( ! function_exists( 'getNextBack' ) ) {
	function getNextBack($w, $type, $current, $current2,$oby=false) {
		
		global $wpdb;
		
		if($type!='blog' && $oby==1) {
			
			$ordering1 = "menu_order";	
			$take = $current;	
			if($w=="next") { 
				$whr = ">";
				$ordering = "asc";
			}else{
				$whr = "<";	
				$ordering = "desc";
			}
			
		}else{
			
			$ordering1 = "post_date";
			$take = $current2;	
			if($w=="prev") { 
				$whr = ">";
				$ordering = "asc";
			}else{
				$whr = "<";	
				$ordering = "desc";
			}
		
		}
		
	  	$myrows = $wpdb->get_row( "SELECT ID, post_title FROM ".$wpdb->posts." WHERE post_type='$type' AND post_status='publish' AND $ordering1 $whr '$take' order by $ordering1 $ordering limit 1" );
		
		
		if(isset($myrows->ID)) {
				return array(
				'post_title'=>$myrows->post_title,
				'ID'=>$myrows->ID
				);
		}
	}
}



	
if ( ! function_exists( 'getCustomPage' ) ) {
	function getCustomPage() { 	
		global $post;
		global $wpdb;
		global $wp_query;
		
		if(isset($post) && $post->post_type=='page') {
			
			$page_type = get_post_meta( $post->ID, 'page-custom-type', true );
			
		}elseif(isset($_REQUEST['type'])){
			
			$page_type = $_REQUEST['type'];
			
		}elseif(isset($wp_query)){
			
			$customtypes = of_get_option('md_custom_posts');
			
			$post_obj = $wp_query->get_queried_object();
			
			if(isset($post_obj->post_type)) {
				$post_title_by = $post_obj->post_type;
			}elseif(isset($post_obj->taxonomy)) {
				$post_title_by = str_replace('-categories','',$post_obj->taxonomy);
			}
			
			
			//$i=1;
			foreach($customtypes as $k => $v) {
				if($v['title']==$post_title_by) { 
					$page_type = $k;
					break;
				}
				//$i++;
			}	
			
		}
		
		return $page_type;	
	}
}

/************************************************************
/* MASTER PAGINATOR
/************************************************************/

/*
if ( ! function_exists( 'custom_posts_pagination' ) ) {	
	function custom_posts_pagination( $query ) {
		
		if( !$query->is_main_query() && $query->is_main_query() ){
			$customtypes = of_get_option('md_custom_posts');
			$page_type = getCustomPage();
			$vartype = @$customtypes[$page_type];
			
			if(isset($vartype['pagination'])) {
				$works_pagination = intval($vartype['pagination']);
				
				if($works_pagination == 0) {
					$works_pagination = -1;
				}
				
				$query->set('posts_per_page', $works_pagination);
			
				return $query;
			}
		}
	}
}
*/
//add_filter('pre_get_posts', 'custom_posts_pagination');

	
/************************************************************
/* MAKE URL
/************************************************************/


if ( ! function_exists( 'makeClickableLinks' ) ) {	
	function makeClickableLinks($s) {
	  return preg_replace_callback('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', 'makeClickableLinkscallbackFunc', $s);
	}
}

if ( ! function_exists( 'makeClickableLinkscallbackFunc' ) ) {	
	function makeClickableLinkscallbackFunc($matches) {
		
		if(strlen($matches[1]) > 32) {
			$lnk = substr($matches[1],0,32).'...';
		}else{
			$lnk = $matches[1];
		}
	
		return '<a href="'.$matches[1].'" target="_blank">'.$lnk.'</a>';
	}
}

/************************************************************
/* Navigation
/************************************************************/

register_nav_menus(  
    array(  
        'main_menu' => 'Main&amp;Mobile Menu')  
    ); 
	

/************************************************************
/* CUSTOM RSS
/************************************************************/

if ( ! function_exists( 'myfeed_request' ) ) {
	function myfeed_request($qv) {
		if (isset($qv['feed']) && !isset($qv['post_type']))
			$qv['post_type'] = array('post', 'works');
		return $qv;
	}
}
add_filter('request', 'myfeed_request');


/************************************************************
/* Get Page Name
/************************************************************/

if ( ! function_exists( 'getPageName' ) ) {	
	function getPageName() {
		global $post;
		global $pagename;
		
		$pagename = get_query_var('pagename');
		if ( !$pagename && isset($id) > 0 ) {
		// If a static page is set as the front page, $pagename will not be set. Retrieve it from the queried object
		$post = $wp_query->get_queried_object();
		$pagename = $post->post_name;
		}
		return ucfirst($pagename);
	}
}


/************************************************************
/* Comments
/************************************************************/

if ( ! function_exists( 'drone_comments' ) ) {		
	function drone_comments( $comment, $args, $depth ) {
	   $GLOBALS['comment'] = $comment; ?>
	   
	   <div <?php comment_class('singlecomment border-color border-color-works'); ?> id="comment-<?php comment_ID() ?>">
		   <div class="who">
			 <span class="img border-color border-color-works">
			 <?php echo get_avatar( $comment, $size = '30', $default = '' );  ?>
			 </span>
			 <span class="info">
				<strong><?php printf( __( '%s', 'dronetv' ), sprintf( '%s', get_comment_author_link() ) ); ?></strong>
				<br />
				<?php echo human_time_diff( get_comment_time('U'), current_time('timestamp') ) . ' ago';  ?>  
				<?php edit_comment_link( __( ' · (Edit)', 'dronetv' ),'  ','' ) ?>
				· <?php comment_reply_link( array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ) ?>    
			 </span>
		   </div>
		  
		  <div class="ccontent"> 
		   <?php if ( $comment->comment_approved == '0' ) : ?>
			 <em><?php _e( 'Your comment is awaiting moderation.', 'dronetv' ) ?></em>
			 <br />
		  <?php endif; ?>
		  
			<?php comment_text() ?>
		   </div> 
	   </div>
	   
	<?php
	}
}


function my_password_form() {
    global $post;
    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
    $o = ''._x('<span style="display:inline-block;padding-top:6px; ">Password protected content. <a href="#" onclick="jQuery(this).parent().next().show();jQuery(this).parent().hide();return false">Click here to view.</a></span>','dronetv').'
	<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post" class="mypassform" style="display:none">
    <input name="post_password" id="' . $label . '" type="password" style="padding:7px; width:100px" placeholder="Password" /><input type="submit" name="Submit" value="' . esc_attr__( "Submit" ) . '" />
    </form>
    ';
    return $o;
}
add_filter( 'the_password_form', 'my_password_form' );

function my_excerpt_password_form( $excerpt ) {
    if ( post_password_required() )
        $excerpt = get_the_password_form();
    return $excerpt;
}
add_filter( 'the_excerpt', 'my_excerpt_password_form' );



/************************************************************
/* PAGINATION GET
/************************************************************/
	
function md_get_page_number() { 

	if(get_query_var('paged') > 1) {
		$current = get_query_var('paged');
	}elseif(get_query_var('page') > 1) {
		$current = get_query_var('page');
	}else{
		$current = 1;
	}
		
	return $current;
		
}



/************************************************************
/* PAGINATION FUNCTION
/************************************************************/
	
	function get_paginate_page_links( $type = 'plain', $endsize = 1, $midsize = 1 ) {
		global $wp_query, $wp_rewrite;  
		
		$current = md_get_page_number();
		
	
		// Sanitize input argument values
		if ( ! in_array( $type, array( 'plain', 'list', 'array' ) ) ) $type = 'plain';
		$endsize = absint( $endsize );
		$midsize = absint( $midsize );
	
		// Setup argument array for paginate_links()
		$pagination = array(
			'base'      => @add_query_arg( 'paged', '%#%' ),
			'format'    => '',
			'total'     => $wp_query->max_num_pages,
			'current'   => $current,
			'show_all'  => false,
			'end_size'  => $endsize,
			'mid_size'  => $midsize,
			'type'      => $type,
			'prev_text' => '&lt;&lt;',
			'next_text' => '&gt;&gt;'
		);
	
		if ( $wp_rewrite->using_permalinks() )
			$pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ).'page/%#%/', 'paged' );
	
		if ( ! empty( $wp_query->query_vars['s'] ) )
			$pagination['add_args'] = array( 's' => get_query_var( 's' ) );
	
		return paginate_links( $pagination );
		

	}





/************************************************************
/* Include Short Codes
/************************************************************/
require_once( THEME_FILEPATH . '/framework/shortcodes/google-map.php');
require_once( THEME_FILEPATH . '/framework/shortcodes/columns.php');
require_once( THEME_FILEPATH . '/framework/shortcodes/contact/contact-form.php');

/************************************************************
/* Admin Function Includes
/************************************************************/
require_once( THEME_FILEPATH . '/framework/custom-post-register.php' );
require_once( THEME_FILEPATH . '/framework/custom-metabox.php' );
require_once( THEME_FILEPATH . '/framework/md-assets.php' );
require_once( THEME_FILEPATH . '/framework/widgets.php' );
require_once( THEME_FILEPATH . '/framework/ajax.php' );
require_once (THEME_FILEPATH . '/framework/tinymce/tinymce.loader.php');
require_once( THEME_FILEPATH . '/framework/tuc.php' );
require_once( THEME_FILEPATH . '/framework/SEO/seo.php' );
	

/// SPECIAL CSS CLASSES FOR POST LOOP
	add_filter('post_class', 'my_post_class');

if ( ! function_exists( 'my_post_class' ) ) {		
	function my_post_class($classes){
	  global $wp_query;
	  if(($wp_query->current_post+1) == $wp_query->post_count) $classes[] = 'end';
	  return $classes;
	}
}	
?>