(function($) {
	
	$(function() { 
		/// YOUR FUNCTIONS GOES HERE
	
	
	
	});
	
})(jQuery)
